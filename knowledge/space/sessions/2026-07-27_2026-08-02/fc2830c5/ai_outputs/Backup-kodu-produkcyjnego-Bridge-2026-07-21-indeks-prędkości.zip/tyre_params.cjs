'use strict';

// POPRAWKA 2026-06-30: importujemy helpery z common.cjs do normalizacji bieżników typu
// "Agriflex 372 +" oraz ekstrakcji PR z indeksów (np. "16P/159A8" -> PR=16, LI/SI=159A8).
const commonHelpers = require('../common.cjs');
const { normalizeBieznikPlus, extractPrFromText } = commonHelpers;

function cleanText(value) {
  return String(value ?? '')
    .replace(/®/g, 'ę')
    .replace(/\s+/g, ' ')
    .trim();
}

function emptyToNull(value) {
  const text = cleanText(value);
  return text ? text : null;
}

function parseNumber(value) {
  if (value === null || value === undefined || value === '') return null;
  const text = String(value)
    .replace(/\s+/g, '')
    .replace(/[^\d,.-]/g, '')
    .replace(',', '.');
  const num = Number.parseFloat(text);
  return Number.isFinite(num) ? num : null;
}

function normalizePrice(value) {
  return parseNumber(value);
}

function normalizeQty(value) {
  const num = parseNumber(value);
  return num === null ? null : Math.trunc(num);
}

function normalizeSizeText(value) {
  let text = cleanText(value);
  text = text.replace(/\bOpona\b/gi, '').trim();
  text = text.replace(/\s*\/\s*/g, '/');
  // POPRAWKA 2026-06-18: poprzednie wersje tych zamian (\s*R\s*, \s*B\s*, \s*x\s*, \s*-\s*)
  // dopasowywały litery R/B/x i myslnik W CALYM tekscie (np. w nazwie producenta/modelu),
  // a nie tylko w obrebie zapisu rozmiaru. Powodowalo to "zjadanie" spacji np. miedzy
  // "...R42" a nazwa producenta zaczynajaca sie na B/R/X ("520/85R42 BKT" -> "520/85R42BKT"),
  // co niszczylo granice slowa (\b) wymagana przez extractMainSize i w efekcie rozmiar=null
  // dla bardzo wielu realnych rekordow (np. producenci BKT, Bridgestone, Barum, marki z "X").
  // Teraz zamiany dzialaja tylko gdy litera/myslnik jest MIEDZY cyframi (czyli realnie
  // czesc zapisu rozmiaru typu "520 / 85 R 42" czy "11.2 - 24").
  text = text.replace(/(\d)\s*-\s*(\d)/g, '$1-$2');
  text = text.replace(/(\d)\s*R\s*(\d)/gi, '$1R$2');
  text = text.replace(/(\d)\s*B\s*(\d)/gi, '$1B$2');
  text = text.replace(/(\d)\s*x\s*(\d)/gi, '$1x$2');
  // POPRAWKA 2026-06-18 (4): realne dane Bohnenkamp (Alliance/Nokian/Deli) maja zapis
  // L-series z ODSTEPAMI i/lub z "R" zamiast "-" jako separatorem, np. "28 L - 26",
  // "28 L R 26", "19.5L R 24", "400 / 45 L - 17.5" — wczesniejszy wzorzec L-series
  // wymagal scisle "L-" bez spacji, wiec te zapisy nigdy nie byly rozpoznawane (rozmiar
  // i wysokosc wychodzily null, mimo ze rozmiar byl obecny w tekscie nazwy). Normalizujemy
  // do kanonicznej postaci "L-" bez wzgledu na oryginalny separator/odstepy.
  text = text.replace(/(\d{1,3}(?:[.,]\d+)?)\s*L\s*[-R]\s*(\d{1,3}(?:[.,]\d+)?)/gi, '$1L-$2');
  return text.replace(/\s+/g, ' ').trim();
}

function extractMainSize(value) {
  const text = normalizeSizeText(value);
  // POPRAWKA 2026-06-18 (3): kilka realnych dodatkowych usterek wykrytych na danych
  // Agrorami (BKT):
  //  a) Kolejnosc wzorcow: 2-liczbowy bias "W-D" lapal SUBSTRING wewnatrz dluzszego
  //     3-liczbowego zapisu "WxP-D" (np. "10.5x80-18" -> bias-D znajdowal "80-18" w
  //     srodku stringa, obcinajac "10.5x" i dajac bledny rozmiar/wysokosc). Naprawka:
  //     wzorzec "WxP-D" musi byc sprawdzany PRZED bias-D.
  //  b) Sufiksy dolepione bez separatora (np. "VF520/60R28NRO", "17.5R25L5" — "NRO"/"L5"
  //     to oznaczenia bieznika/zastosowania BKT, nie czesc rozmiaru) blokowaly \b na
  //     koncu wzorca (cyfra+litera to oba znaki \w, brak granicy). Naprawka: koniec
  //     wzorcow 1/2/3 zamieniony z \b na (?![\d.]) — pozwala litery po rozmiarze,
  //     ale wciaz blokuje "dociaganie" kolejnych cyfr (zapobiega bledom typu 85R2|5).
  //  c) Format "WxD" bez profilu (2 liczby, separator "x", bez segmentu "-srednica"),
  //     np. "7x14", "8x16", "12,00x24" — kompletnie nieobslugiwany. Nowy wzorzec na
  //     koniec listy (po 3-liczbowym wariancie, ktory ma priorytet gdy obie czesci sa).
  // POPRAWKA 2026-07-17 (Handlopex): notacja calowa "A x B - D" (np. "23 x 10.50 - 12",
  // "26 x 12.00 - 12") — po normalizacji spacji daje "23x10.50-12". MUSI byc pierwsza,
  // przed wzorcem radialnym, ktory inaczej zlapalby kod bieznika "600R1"/"374R1" ("MTR
  // 600 R1", "MIM 374 R1") jako rzekomy rozmiar. Rowniez dopuszczamy 1-cyfrowa szerokosc
  // z ulamkiem przed "/" (np. "6.50/80-15" Ozka/GTK) — wczesniej \d{2,4} wymagalo 2 cyfr
  // i "6.50/80-15" spadalo do bias "50/80-15" (utrata "6.").
  const patterns = [
    /\b\d{1,3}(?:[.,]\d+)?x\d{1,3}(?:[.,]\d+)?-\d{1,3}(?:[.,]\d+)?(?![\d.])/i,
    /\b(?:VF|IF)?\d{1,4}(?:[.,]\d+)?\/\d{1,3}(?:[.,]\d+)?[RBD-]\d{1,3}(?:[.,]\d+)?(?![\d.])/i,
    // slash + L-series z podanym profilem (np. "400/45L-17.5") — MUSI byc przed plain
    // L-series nizej, inaczej plain L-series zlapie tylko fragment po "/" (profil
    // pomylony z szerokoscia, prefiks "400/" zostaje odciety).
    /\b\d{2,4}(?:[.,]\d+)?\/\d{1,3}(?:[.,]\d+)?L-\d{1,3}(?:[.,]\d+)?(?![\d.])/i,
    // POPRAWKA 2026-07-15: "WWW/PPxDD" (3 liczby, separator "/" miedzy szerokoscia i
    // profilem, "x" miedzy profilem i srednica — np. "550/45x22,5", "13,0/65x18").
    // Realne dane Agrorami (BKT) uzywaja tej notacji dla opon flotacyjnych. Bez tego
    // wzorca dopasowanie "spadalo" do prostego "WxD" nizej, ktore lapalo TYLKO ostatnie
    // dwie liczby (profil x srednica), gubiac prefiks szerokosci przed "/" — np.
    // "550/45x22,5" -> bledne "45x22.5" (szerokosc "550" utracona). MUSI byc przed
    // "WxP-D" i plain "WxD" nizej, inaczej te wzorce zlapia tylko podciag.
    /\b\d{2,4}(?:[.,]\d+)?\/\d{1,3}(?:[.,]\d+)?x\d{1,3}(?:[.,]\d+)?(?![\d.])/i,
    /\b\d{1,3}(?:[.,]\d+)?[RBD]\d{1,3}(?:[.,]\d+)?(?![\d.])/i,
    // notacja flotacyjna L-series (np. "30.5L-32", "17.5L-24", "28L-26")
    /\b\d{1,3}(?:[.,]\d+)?L-\d{1,3}(?:[.,]\d+)?(?![\d.])/i,
    // "WxP-D" (3 liczby, np. "10.5x80-18") — MUSI byc przed bias-D "W-D", inaczej
    // bias-D zlapie tylko ostatnie dwie liczby.
    /\b\d{1,3}(?:[.,]\d+)?x\d{1,3}(?:[.,]\d+)?-\d{1,3}(?:[.,]\d+)?\b/i,
    /(?<![\d.])\d{1,3}(?:[.,]\d+)?-\d{1,3}(?:[.,]\d+)?(?![\d.])/i,
    // "WxD" (2 liczby, bez profilu, np. "7x14", "12,00x24")
    /\b\d{1,3}(?:[.,]\d+)?x\d{1,3}(?:[.,]\d+)?\b/i
  ];
  for (const pattern of patterns) {
    const match = text.match(pattern);
    // POPRAWKA 2026-07-17 (Handlopex): odrzucamy oznaczenie wzoru bieznika "R1"/"R2"/"R3"
    // (norma rolnicza R-1/R-2), ktore po sklejeniu spacji wyglada jak krotki radialny
    // "600R1"/"374R1". Sygnatura: czlon po R = pojedyncza cyfra 1-3 ORAZ pierwszy czlon
    // >=100 (realna srednica opony w calach nie przekracza ~60). Pomijamy dopasowanie i
    // szukamy dalej (nastepny wzorzec / dalsza czesc tekstu).
    if (match) {
      const rr = match[0].match(/^(\d+(?:[.,]\d+)?)R(\d+(?:[.,]\d+)?)$/i);
      if (rr && parseFloat(rr[2].replace(',', '.')) <= 3 && parseFloat(rr[1].replace(',', '.')) >= 100) {
        continue;
      }
    }
    // POPRAWKA 2026-07-15: replace(',', '.') zamienial TYLKO PIERWSZY przecinek —
    // dla zapisow z DWOMA liczbami dziesietnymi w jednym rozmiarze (np. szerokosc
    // "11,5" ORAZ srednica "15,3" w "11,5/80x15,3") drugi przecinek zostawal
    // nietkniety, co powodowalo ze parseSize() nie dopasowywal go (regexy tam
    // oczekuja "." jako separatora), dajac szerokosc=null/profil=null/srednica=null
    // mimo ze rozmiar byl prawidlowo wykryty. W kontekscie zapisu rozmiaru opony
    // przecinek ZAWSZE oznacza separator dziesietny (nigdy separator tysiecy), wiec
    // zamiana WSZYSTKICH przecinkow na kropki jest bezpieczna.
    if (match) return normalizeSizeText(match[0]).replace(/,/g, '.');
  }
  return null;
}

function parseSize(value) {
  const raw = normalizeSizeText(value);
  const size = extractMainSize(raw);
  const result = {
    rozmiar: size,
    szerokosc: null,
    profil: null,
    srednica: null,
    konstrukcja: null,
    wysokoscRzeczywistaCm: null,
    wysokoscBokuCm: null
  };
  if (!size) return result;

  // POPRAWKA 2026-07-15: "WWW/PPxDD" (szerokosc/profil x srednica), np. "550/45x22.5"
  // — notacja flotacyjna Agrorami/BKT. Sprawdzana PRZED reszta kaskady (musi wygrac
  // z prostym "WxD" nizej, ktore inaczej zlapaloby tylko podciag "profilxśrednica" i
  // ucinaloby prefiks szerokosci). Flaga matched3PartSlashX chroni wynik przed
  // nadpisaniem przez dalsze warunki w kaskadzie (analogicznie do ochrony L-series).
  let matched3PartSlashX = false;
  let match = size.match(/^(\d{2,4}(?:\.\d+)?)\/(\d{1,3}(?:\.\d+)?)x(\d{1,3}(?:\.\d+)?)$/i);
  if (match) {
    result.szerokosc = parseNumber(match[1]);
    result.profil = parseNumber(match[2]);
    result.konstrukcja = 'D';
    result.srednica = parseNumber(match[3]);
    matched3PartSlashX = true;
    match = null;
  } else {
    match = size.match(/^(\d{2,4}(?:\.\d+)?)\/(\d{1,3}(?:\.\d+)?)L-(\d{1,3}(?:\.\d+)?)$/i);
  }
  if (match) {
    // slash + L-series z profilem, np. "400/45L-17.5"
    result.szerokosc = parseNumber(match[1]);
    result.profil = parseNumber(match[2]);
    result.konstrukcja = 'L';
    result.srednica = parseNumber(match[3]);
    match = null;
  } else if (!matched3PartSlashX) {
    match = size.match(/^(VF|IF)?(\d{2,4}(?:\.\d+)?)\/(\d{1,3}(?:\.\d+)?)([RBD-])(\d{1,3}(?:\.\d+)?)$/i);
  }
  if (match) {
    result.szerokosc = parseNumber(match[2]);
    result.profil = parseNumber(match[3]);
    const k = match[4].toUpperCase();
    result.konstrukcja = k === '-' ? 'D' : k;
    result.srednica = parseNumber(match[5]);
  } else if (!matched3PartSlashX && result.konstrukcja !== 'L') {
    match = size.match(/^(\d{1,3}(?:\.\d+)?)([RBD])(\d{1,3}(?:\.\d+)?)$/i);
    if (match) {
      result.szerokosc = parseNumber(match[1]);
      result.konstrukcja = match[2].toUpperCase();
      result.srednica = parseNumber(match[3]);
    } else {
      match = size.match(/^(\d{1,3}(?:\.\d+)?)-(\d{1,3}(?:\.\d+)?)$/);
      if (match) {
        result.szerokosc = parseNumber(match[1]);
        result.profil = null;
        result.konstrukcja = 'D';
        result.srednica = parseNumber(match[2]);
      } else {
        // POPRAWKA 2026-06-18: notacja L-series (szerokosc + "L" + "-" + srednica),
        // np. "30.5L-32". Brak profilu (jak przy bias "D"), wiec domyslny profil 83%
        // jest stosowany dalej w obliczeniu wysokosci tak jak dla konstrukcji "D".
        match = size.match(/^(\d{1,3}(?:\.\d+)?)L-(\d{1,3}(?:\.\d+)?)$/i);
        if (match) {
          result.szerokosc = parseNumber(match[1]);
          result.profil = null;
          result.konstrukcja = 'L';
          result.srednica = parseNumber(match[2]);
        } else {
          // POPRAWKA 2026-06-18 (3): zapis "WxP-D" (3 liczby, separator "x" miedzy
          // szerokoscia i profilem, np. "10.5x80-18") — tradycyjna notacja bias-ply.
          match = size.match(/^(\d{1,3}(?:\.\d+)?)x(\d{1,3}(?:\.\d+)?)-(\d{1,3}(?:\.\d+)?)$/i);
          if (match) {
            result.szerokosc = parseNumber(match[1]);
            result.profil = parseNumber(match[2]);
            result.konstrukcja = 'D';
            result.srednica = parseNumber(match[3]);
          } else {
            // zapis "WxD" (2 liczby, bez profilu, np. "7x14", "12,00x24")
            match = size.match(/^(\d{1,3}(?:\.\d+)?)x(\d{1,3}(?:\.\d+)?)$/i);
            if (match) {
              result.szerokosc = parseNumber(match[1]);
              result.profil = null;
              result.konstrukcja = 'D';
              result.srednica = parseNumber(match[2]);
            }
          }
        }
      }
    }
  }

  if (result.szerokosc !== null && result.srednica !== null) {
    const metricWidth = result.szerokosc >= 100;
    const widthCm = metricWidth ? result.szerokosc / 10 : result.szerokosc * 2.54;
    const profile = result.profil ?? 83;
    result.wysokoscBokuCm = Math.round(widthCm * (profile / 100) * 100) / 100;
    result.wysokoscRzeczywistaCm = Math.round((result.wysokoscBokuCm * 2 + result.srednica * 2.54) * 100) / 100;
  }

  return result;
}

function parseLoadSpeed(value) {
  let text = cleanText(value).replace(/\s*\/\s*/g, '/').replace(/\s+/g, '');
  if (!text) return { indeksNosnosci: null, indeksPredkosci: null };
  // POPRAWKA 2026-07-01: usuwamy tokeny "NPR" (np. "10PR","12PR","20PR") PRZED matchem load/speed.
  // Regex load/speed [A-Z]\d? łapie tylko literę P a nie PR — więc dla "10PR" match dawał "10P",
  // sprawdzenie /PR$/i.test(match[0]) było fałszem (bo brakuje R), i "10P" trafiał jako fałszywy indeks.
  // Objaw: 17.5-25 ALIANNCE 308 16P/158B 16PR TL zamiast 17.5-25 ALIANNCE 308 158B 16PR TL.
  // Regex: 1-2 cyfry + PR poprzedzone niecyfrą/nieliterą (żeby nie zjadać np. "559PR" — nie ma takich)
  // i następnie NIE literowy znak (żeby nie zjadać "12PR159A8" → "12PR" musi się kończyć tam, gdzie zaczyna się cyfra).
  // Aplikujemy w pętli 3x na wypadek nakładających się podłańcuchów (edge case).
  // Poprzedzenie: brak litery/cyfry (albo początek); następnie NPR nie może być kontynuowany kolejną
  // literą z klasy indeksów prędkości (przypadki jak "NPRT" nie istnieją w indeksach opon).
  // Uwaga: \b w JS nie stanowi granicy między literą a cyfrą (obie są "word chars"),
  // więc używamy jawnych lookaheadów: koniec, niecyfra/nieliterowe, cyfra (kolejny token liczbowy),
  // lub 1-2 liter (kolejny marker jak TT/TL/MPT).
  for (let i = 0; i < 3; i++) {
    text = text.replace(/(?<![A-Z0-9])(\d{1,2})PR(?=$|[^A-Z0-9]|\d|[A-Z]{1,4}(?![A-Z0-9]))/gi, '');
  }
  text = text.replace(/\/+/g, '/').replace(/^\/+|\/+$/g, '');
  if (!text) return { indeksNosnosci: null, indeksPredkosci: null };
  const direct = text.match(/^(\d{2,3})([A-Z]\d?)\/(\d{2,3})([A-Z]\d?)$/i);
  if (direct) {
    return {
      indeksNosnosci: `${direct[1]}/${direct[3]}`,
      indeksPredkosci: `${direct[2].toUpperCase()}/${direct[4].toUpperCase()}`
    };
  }
  const pairs = [];
  const re = /(\d{2,3})([A-Z]\d?)/gi;
  let match;
  while ((match = re.exec(text)) !== null) {
    pairs.push({ load: match[1], speed: match[2].toUpperCase() });
  }
  if (!pairs.length) return { indeksNosnosci: null, indeksPredkosci: null };
  return {
    indeksNosnosci: pairs.map(p => p.load).join('/'),
    indeksPredkosci: pairs.map(p => p.speed).join('/')
  };
}

function normalizeTlTt(value) {
  const text = cleanText(value).toUpperCase();
  if (!text) return null;
  // POPRAWKA 2026-06-30: TTF (Tube Type with Flap) → TT.
  // Sprawdzane przed TL/TT, bo TTF zawiera "TT" jako podciąg.
  if (/\bTTF\b/.test(text)) return 'TT';
  if (text.includes('TL')) return 'TL';
  if (text.includes('TT')) return 'TT';
  return null;
}

function inferProducerFromName(name, sizeText) {
  const text = cleanText(name).replace(/^opona\s+/i, '');
  const escapedSize = cleanText(sizeText).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const withoutSize = escapedSize ? text.replace(new RegExp(`^${escapedSize}\\s*`, 'i'), '') : text;
  const token = emptyToNull(withoutSize.split(/\s+/)[0]);
  if (!token || /^\d/.test(token) || /^(TL|TT|PR|VF|IF|DOT)$/i.test(token)) return null;
  return token;
}

function parseTechnicalMarks(...values) {
  const text = values.map(v => cleanText(v)).join(' ');
  const upper = text.toUpperCase();
  const loadSpeed = parseLoadSpeed(text);
  const prMatch = upper.match(/\b(\d{1,2})\s*PR\b/);
  return {
    ...loadSpeed,
    pr: prMatch ? prMatch[1] : null,
    // POPRAWKA 2026-06-30: TTF (Tube Type with Flap) traktujemy jak TT.
    tlTt: /\bTL\b/.test(upper) ? 'TL' : (/\bTTF\b/.test(upper) || /\bTT\b/.test(upper)) ? 'TT' : null,
    // POPRAWKA 2026-06-22: \bVF\b nie lapie "VF320/85R34" (granica slowa nie dziala
    // miedzy F a cyfra). Akceptujemy zarowno samodzielne VF/IF jak i przyklejone do
    // szerokosci (prefix rozmiaru), np. "VF320", "IF710".
    vfIf: /\bVF(?:\b|(?=\d))/.test(upper) ? 'VF' : /\bIF(?:\b|(?=\d))/.test(upper) ? 'IF' : null,
    nro: /\bNRO\b/.test(upper) ? 1 : 0,
    cho: /\bCHO\b/.test(upper) ? 1 : 0,
    cfo: /\bCFO\b/.test(upper) ? 1 : 0,
    sb: /\bSB\b|\bSTEEL BELTED\b/.test(upper) ? 1 : 0,
    sf: /\bSF\b/.test(upper) ? 1 : 0,
    stubbleResistant: /\bSTUBBLE\b/.test(upper) ? 1 : 0
  };
}

function parseJmkLoadSpeed(row) {
  const speed1 = emptyToNull(row.speed1);
  const speed2 = emptyToNull(row.speed2);
  const load1Raw = emptyToNull(row.load1);
  const load2Raw = emptyToNull(row.load2);
  const loads = [];
  const speeds = [];
  let pr = null;

  function addLoadSpeed(loadRaw, speedRaw) {
    if (!loadRaw) return;
    const prMatch = loadRaw.match(/^(\d{1,2})\s*PR$/i);
    if (prMatch) {
      pr = prMatch[1];
      return;
    }
    // POPRAWKA 2026-06-30: JMK potrafi wpisać "16PR/159A8" albo "16P/159A8" w jednym polu
    // Indeks Nośności. "16PR/159A8" przedtem trafiało w całości do parseLoadSpeed,
    // gdzie "16PR" traktowane było jako indeks nośności a "159A8" jako indeks prędkości
    // — w nazwie wychodziło "16P/159A8 16PR TL". Najpierw próbujemy wydobyć PR z formatu "NP"
    // (extractPrFromText obsługuje również "NPR" — ale dla pewności preprocesujemy obie wersje).
    // 1) Jawne "NPR" w dowolnym miejscu — podmieniamy na separator i zapamiętujemy PR.
    const explicitPr = loadRaw.match(/(^|[\s\/\-])(\d{1,3})PR(?=$|[\s\/\-])/i);
    if (explicitPr) {
      pr = explicitPr[2];
      loadRaw = loadRaw.replace(explicitPr[0], explicitPr[1]).replace(/^[\s\/\-]+|[\s\/\-]+$/g, '').replace(/\s*\/\s*\/\s*/g, '/').trim();
    }
    // 2) "NP" (bez R) — też PR.
    const prExtracted = extractPrFromText(loadRaw);
    if (prExtracted.pr) {
      pr = prExtracted.pr;
      loadRaw = prExtracted.cleaned;
    }
    if (!loadRaw) return;
    const embedded = parseLoadSpeed(loadRaw);
    if (embedded.indeksNosnosci && embedded.indeksPredkosci) {
      const loadParts = embedded.indeksNosnosci.split('/');
      const speedParts = embedded.indeksPredkosci.split('/');
      for (let i = 0; i < loadParts.length; i++) {
        loads.push(loadParts[i]);
        speeds.push(speedParts[i] || speedRaw || null);
      }
      return;
    }
    loads.push(loadRaw.replace(/\s+/g, ''));
    speeds.push(speedRaw || null);
  }

  addLoadSpeed(load1Raw, speed1);
  addLoadSpeed(load2Raw, speed2);

  // POPRAWKA 2026-07-21: gdy tylko jedna z dwoch predkosci jest znana (np. JMK/MO2
  // podaje druga nosnosc bez drugiej predkosci), poprzedni kod dawal "/K" albo "J/"
  // (pusty slot + ukosnik). Jesli faktycznie znany jest tylko jeden indeks predkosci,
  // zapisujemy go samodzielnie, bez ukosnika.
  const knownSpeeds = speeds.filter(Boolean);
  const indeksPredkosciFinal = knownSpeeds.length === 0
    ? null
    : (knownSpeeds.length === speeds.length ? speeds.join('/') : knownSpeeds.join('/'));

  return {
    indeksNosnosci: loads.length ? loads.join('/') : null,
    indeksPredkosci: indeksPredkosciFinal,
    pr
  };
}

function formatLiSi(load, speed) {
  if (!load || !speed) return null;
  const loads = String(load).split('/');
  const speeds = String(speed).split('/');
  if (loads.length > 1 && speeds.length === 1) return `${loads.join('/')}${speeds[0]}`;
  // POPRAWKA 2026-07-10: brakowalo symetrycznego przypadku "1 nosnosc + wiele predkosci"
  // (np. load="170", speed="A8/B" — skrocony zapis Agrorami "170A8/B"). Wczesniej kod
  // szedl prosto do .map() nad `loads` (dlugosc 1), co obcinalo dodatkowe elementy
  // `speeds` i gubilo np. "/B" — wynik byl tylko "170A8" zamiast "170A8/B".
  if (loads.length === 1 && speeds.length > 1) return `${loads[0]}${speeds.join('/')}`;
  return loads.map((li, idx) => `${li}${speeds[idx] || speeds[0] || ''}`).join('/');
}

function normalizeJmk(record) {
  const konstrukcjaRaw = emptyToNull(record.konstrukcja);
  const konstrukcjaMark = konstrukcjaRaw === '-' ? '-' : konstrukcjaRaw || (/R/i.test(record.nazwa || '') ? 'R' : '-');
  const rozmiar = record.rozmiar || [
    record.szerokosc,
    record.profil ? `/${record.profil}` : '',
    konstrukcjaMark === '-' ? '-' : konstrukcjaMark,
    record.srednica
  ].filter(Boolean).join('');
  const size = parseSize(rozmiar || record.nazwa);
  const loadSpeed = parseJmkLoadSpeed({
    speed1: record.indeksPredkosci1,
    speed2: record.indeksPredkosci2,
    load1: record.indeksNosnosci1,
    load2: record.indeksNosnosci2
  });
  const marks = parseTechnicalMarks(record.nazwa, record.system);
  const kategoria = cleanText(record.rodzaj).toLowerCase() || null;
  const liSi = formatLiSi(loadSpeed.indeksNosnosci, loadSpeed.indeksPredkosci);
  const cenaZakupu = normalizePrice(record.cenaKlientNetto);
  const stan = normalizeQty(record.magazyn1);
  // POPRAWKA 2026-06-30: normalizujemy bieżnik wg reguły Anny — różne warianty zapisu
  // marek typu "Agriflex 372 +" muszą mieć wspólny kanoniczny format.
  let model = emptyToNull(record.bieznik);
  if (model) model = normalizeBieznikPlus(model);
  const marka = emptyToNull(record.producent);
  // POPRAWKA 2026-07-03: Alliance Agriflex — JMK w źródle nie oznacza VF/IF w nazwie,
  // musimy dorobić prefiks z modelu.
  // Agriflex 354 = IF Flexion, Agriflex 363/372/373/377/389 = VF Flexion (Alliance).
  if (!marks.vfIf && marka && /^Alliance$/i.test(marka) && model) {
    if (/Agriflex\s*354\b/i.test(model)) marks.vfIf = 'IF';
    else if (/Agriflex\s*(363|372|373|377|389)\b/i.test(model)) marks.vfIf = 'VF';
  }
  const result = {
    kategoria,
    kodDostawcy: emptyToNull(record.kodProducenta),
    ean: emptyToNull(record.ean),
    marka,
    model,
    rozmiar: size.rozmiar,
    rozmiarAlternatywny: emptyToNull(record.zamiennik),
    szerokosc: size.szerokosc ?? parseNumber(record.szerokosc),
    profil: size.profil ?? parseNumber(record.profil),
    srednica: size.srednica ?? parseNumber(record.srednica),
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    konstrukcja: konstrukcjaRaw === '-' ? 'D' : konstrukcjaRaw || size.konstrukcja,
    indeksNosnosci: loadSpeed.indeksNosnosci,
    indeksPredkosci: loadSpeed.indeksPredkosci,
    pr: loadSpeed.pr || marks.pr,
    tlTt: marks.tlTt,
    ms: /\bM\+S\b/i.test(record.nazwa || '') ? 1 : 0,
    snow3pmsf: /\b3PMSF\b/i.test(record.nazwa || '') ? 1 : 0,
    pozycjaOsi: /\bFRONT\b/i.test(record.nazwa || '') ? 'FRONT' : /\bDRIVE\b/i.test(record.nazwa || '') ? 'DRIVE' : null,
    labelRolling: emptyToNull(record.oporToczenia),
    labelWet: emptyToNull(record.przyczepnosc),
    labelNoiseClass: emptyToNull(record.halasKlasa),
    labelNoise: emptyToNull(record.halasDb),
    dot: emptyToNull(record.dot) || 'nie starsza niz 3 lata',
    waga: parseNumber(record.masaBrutto),
    stan,
    cenaZakupu,
    // POPRAWKA 2026-07-03: przekazujemy vfIf do wyniku (wcześniej gubiony)
    vfIf: marks.vfIf
  };
  // POPRAWKA 2026-07-03: prefix VF/IF przed rozmiarem (bez spacji, wg konwencji Bohnenkamp)
  const sizeForName = result.vfIf ? `${result.vfIf}${result.rozmiar}` : result.rozmiar;
  result.nazwaKoncowa = [
    sizeForName,
    marka,
    model,
    liSi,
    result.pr ? `${result.pr}PR` : null,
    result.tlTt,
    result.snow3pmsf ? '3PMSF' : null,
    result.ms ? 'M+S' : null,
    result.pozycjaOsi
  ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  return result;
}

function stripProducerAndModelFromName(name, size, producer) {
  let text = removeSizePrefixFromName(name, size)
    .replace(/\bOpona\b/gi, '')
    .replace(/(?<![\d.])\d{1,3}(?:[.,]\d+)?-\d{1,3}(?:[.,]\d+)?(?![\d.])/g, '')
    .replace(/\b\d{1,2}\s*PR\b/gi, '')
    .replace(/\bTL\b|\bTT\b/gi, '')
    .replace(/\bdemo\b/gi, '')
    // POPRAWKA 2026-06-30 (v4): DOT jest osobnym polem — wycinamy z nazwy modelu.
    .replace(/\bDOT\s*\d{2,4}\b/gi, '')
    .trim();
  if (producer) text = text.replace(new RegExp(`\\b${producer.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i'), ' ');
  return text.replace(/\s+/g, ' ').trim() || null;
}

function firstImageUrl(value) {
  const text = cleanText(value);
  if (!text) return null;
  return text.split(',').map(v => v.trim()).filter(Boolean)[0] || null;
}

function shouldRejectGrasdorf(record) {
  const name = String(record.name || '').trim();
  const text = `${record.category || ''} ${name}`.toLowerCase();

  // POPRAWKA 2026-07-01 (v6 MO3): Decyzja Anny — whitelist zamiast blacklist.
  // Plik Grasdorfa opisuje każdą oponę jako "Opona <rozmiar> ...", więc importujemy
  // TYLKO pozycje które zaczynają się od słowa "Opona". Wszystko inne (Komplet kół,
  // Felga, Łącznik, Dętka, akcesoria, itp.) — odrzucamy.
  // Format B (abstore, 33 kol.) ma name typu "22x11.00-10 Journey P328 6PR TL" bez
  // prefiksu "Opona" — wtedy sprawdzamy czy jest tam rozmiar opony (regex niżej)
  // albo pomijamy filtr gdy record ma additionalName/indexCatalogue (wskazuje format B).
  const isFormatB = !!(record.additionalName || record.indexCatalogue);
  const startsWithOpona = /^opona\b/i.test(name);
  const hasTyreSizePattern = /\b\d{2,4}[/\-x]\d{1,3}([/\-x]?R?\d{1,3})?\b/i.test(name);

  if (!isFormatB && !startsWithOpona) {
    // Format A (grasdorfCSV.csv, 16 kol.) — wymagamy prefiksu "Opona"
    // (odrzucamy "Komplet kół", "Felga", "ŁĄCZNIK", "Dętka", itd.)
    return { reason: 'nie_opona' };
  }
  if (isFormatB && !hasTyreSizePattern) {
    // Format B — nazwa musi zawierać rozmiar opony (np. "22x11.00-10", "460/85R38")
    // Žeby odrzucić wpisy typu "ŁĄCZNIK W10x38" (nie ma / lub -) czy "Felga 10x42" (ma rozmiar felgi ale nie opony).
    return { reason: 'nie_opona' };
  }

  // Nadal sprawdzamy blacklist na wypadek że "Opona" jest tylko w opisie kompletu
  // (np. "Opona + felga zestaw", choć to rzadkość).
  if (/(felg|śrub|srub|nakręt|nakret|akcesor|quad|atv|łączni|laczni|zaw[oó]r|oring|o-ring|obr[eę]cz|obrecz|ochraniacz|d[eę]tk|detk|bie[zzż]nikowan)/i.test(text)) {
    return { reason: 'akcesoria' };
  }

  // POPRAWKA 2026-07-01 (v5 MO3): Decyzja Anny — odrzucamy TYLKO opony używane.
  if (/u[zż]ywan/i.test(text)) return { reason: 'uzywane' };
  const stanOpony = `${record.stan || record.stanOpony || ''}`.toLowerCase();
  if (/u[zż]ywan/i.test(stanOpony)) return { reason: 'uzywane' };

  return false;
}

function normalizeGrasdorf(record) {
  if (shouldRejectGrasdorf(record)) {
    // POPRAWKA 2026-07-01 (v5): rozróżnij powód odrzucenia (akcesoria vs używane)
    const text = `${record.category || ''} ${record.name || ''} ${record.stan || record.stanOpony || ''}`.toLowerCase();
    if (/u[zż]ywan/i.test(text)) {
      return { odrzucony: true, powod: 'opony używane nie sa importowane' };
    }
    return {
      odrzucony: true,
      powod: 'akcesoria/felgi nie sa importowane'
    };
  }

  // POPRAWKA 2026-06-30 (v3 MO3): pola STRUKTURALNE z CSV Grasdorfa są źródłem prawdy.
  // Wcześniej parser polegał głównie na regexach z nazwy, co dawało:
  //  - profil sklejony ze średnicą (np. R2 zamiast R28),
  //  - model zawierający LI/SI (np. "AC 65 157D/160A8" zamiast "AC 65"),
  //  - duplikaty indeksów w nazwie końcowej,
  //  - kategoria 'przemyslowe' dla rolniczych (path "Opony rolnicze i przemysłowe"
  //    wpadał w regex /przemys/ — teraz "Zastosowanie" ma wyższy priorytet),
  //  - brak TL/TT (kolumna "Typ" była nieprzeczytana bo klucze polskie).
  // Klucze polskich nagłówków są mapowane na camelCase przez mo3_grasdorf.cjs (HEADER_MAP).
  //
  // === ROZMIAR ===
  // "Rozmiar opony" = szer/profil (np. "440/65"), "Średnica felgi" = średnica (np. "24"),
  // "Konstrukcja opony" = "Radialna"/"Diagonalna". Składamy strukturalnie.
  const konstrukcjaTxt = cleanText(record.konstrukcja).toLowerCase();
  const konstrCode = konstrukcjaTxt.includes('radial') ? 'R' : konstrukcjaTxt.includes('diagonal') ? '-' : null;
  const rozmiarOponyTxt = cleanText(record.rozmiarOpony);
  const srednicaFelgiTxt = cleanText(record.srednicaFelgi);
  let sizeFromStruct = { rozmiar: null, szerokosc: null, profil: null, srednica: null, konstrukcja: null, wysokoscRzeczywistaCm: null };
  if (rozmiarOponyTxt && srednicaFelgiTxt && konstrCode) {
    sizeFromStruct = parseSize(`${rozmiarOponyTxt}${konstrCode}${srednicaFelgiTxt}`);
  }
  const sizeFromName = parseSize(record.name);
  const sizeFromField = parseSize(record.rozmiarOpony);
  // Priorytet: pola strukturalne > nazwa > samo "Rozmiar opony".
  const size = sizeFromStruct.rozmiar ? sizeFromStruct : (sizeFromName.rozmiar ? sizeFromName : sizeFromField);

  // === PRODUCENT ===
  const producer = emptyToNull(record.producer) || inferProducerFromName(record.name, size.rozmiar);

  // === MODEL (bieżnik) ===
  // PRIORYTET: "Rodzaj bieżnika" z CSV — czysty model bez LI/SI/PR/TL (np. "AC 65", "T421", "LG 306").
  // Fallback do regexa z nazwy tylko gdy kolumna pusta. Wynik fallbacka czyścimy z LI/SI/PR/TL,
  // bo stripProducerAndModelFromName potrafi zostawić indeksy (np. "585 144A8/144B" zamiast "585")
  // — te potem trafiłyby do nazwy końcowej jako duplikat (bo LI/SI dodajemy z pola strukturalnego).
  const modelFromField = cleanText(record.rodzajBieznika);
  let model = modelFromField;
  // POPRAWKA 2026-07-03: Grasdorf w kolumnie "Rodzaj bieżnika" zapisuje czasem
  // puste nawiasy tam gdzie zwykle jest alt-size (np. "TR 126 ( )", "( ) Maglift LIP").
  // Usuwamy je bo trafiają do nazwy końcowej. Nie ruszamy nawiasów z zawartością ("(17.5R24)").
  if (model) {
    model = model.replace(/\(\s*\)/g, '').replace(/\s+/g, ' ').trim() || null;
  }
  if (!model) {
    const rawFallback = stripProducerAndModelFromName(record.name, size.rozmiar, producer);
    if (rawFallback) {
      // Wycinamy pary LI/SI (np. "144A8/144B", "168D/165E") oraz pojedyncze (np. "164D"),
      // PR ("6PR"), TL/TT z końca. Pozostaje czysta nazwa modelu.
      // POPRAWKA 2026-07-01 (v7 MO3): Grasdorf skraca drugą część indeksu do samej litery,
      // np. "109A8/106B" → "109A8/B". Regex musi złapać też wariant bez cyfr przed literą.
      model = rawFallback
        .replace(/\b\d{2,3}[A-Z]\d?(?:\s*\/\s*(?:\d{2,3})?[A-Z]\d?)?\b/g, ' ')
        .replace(/\b\d{1,2}\s*PR\b/gi, ' ')
        .replace(/\b(TL|TT|TTF)\b/gi, ' ')
        // POPRAWKA 2026-06-30 (v4): sufiks indeksu z końcowym ukośnikiem (np. "HO303 139/")
        // — pojawia się gdy LI/SI ma formę "139/137K" i tylko "137K" zostanie złapane przez regex powyżej.
        .replace(/\s+\d{2,3}\s*\/\s*$/g, ' ')
        .replace(/\s+\d{2,3}\/(?=\s|$)/g, ' ')
        .replace(/\s+/g, ' ')
        .trim() || null;
    }
  }
  // POPRAWKA 2026-06-30 (v4): normalizacja modelu Bridgestone VXR/VX-Tractor.
  // Decyzja Anny: "VXR Tractor" / "VXR-Tractor" / "VX-Tractor" → "VX Tractor".
  // Występuje również w "Rodzaj bieżnika" (np. "VXR-TRACTOR") i w nazwie ("Bridgestone VX-Tractor").
  if (model && producer && /bridgestone/i.test(producer)) {
    model = model.replace(/\bVXR[\s-]*Tractor\b/gi, 'VX Tractor')
                 .replace(/\bVX[\s-]+Tractor\b/gi, 'VX Tractor');
  }

  // === INDEKSY LI/SI ===
  // "Indeks nośności" z CSV ma format "128D/131A8 (1950 kg przy 40 km/h)" lub "164D".
  // Wycinamy nawias z (kg/km/h) i parsujemy. To źródło prawdy dla LI/SI.
  const cleanIndexText = cleanText(record.indeksNosnosci).replace(/\([^)]*\)/g, '').trim();
  const indexedFromField = parseLoadSpeed(cleanIndexText);
  // POPRAWKA 2026-06-30 (v3 MO3): hybrydowe źródło LI/SI.
  // Plik Grasdorfa (test workspace) ma pola strukturalne wypełnione → "Indeks nośności" jest źródłem prawdy.
  // Plik Anny (inwentaryzacja, produkcyjny URL) ma WSZYSTKIE pola strukturalne puste → wszystko trzeba
  // wyciągnąć z nazwy. Stary parser parsował LI/SI z całej nazwy i łapał:
  //  - fragment rozmiaru ("460/70R24 ... 150A8/147B" → "70R2" + "150A8/147B"),
  //  - oznaczenia modelu z liczbą ze spacją ("AC 70 T" → "70T" jako LI/SI).
  // Fix: 1) usuwamy rozmiar z nazwy, 2) szukamy LI/SI tylko przez \b (granica słowa)
  // — z zachowanymi spacjami, żeby "70 T" nie skleiło się w "70T".
  const nameWithoutSize = removeSizePrefixFromName(record.name, size.rozmiar);
  // Szukamy par LI/SI (np. "140A8/140B", "125A8/122B") albo pojedynczych ("164D", "141D").
  // \b działa na granicy słowa — "70 T" NIE jest pojedynczym tokenem, więc nie zostanie złapane.
  // Najpierw szukamy pary (priorytet), potem pojedyncze.
  let indexedFromName = { indeksNosnosci: null, indeksPredkosci: null };
  const pairMatch = nameWithoutSize.match(/\b(\d{2,3})([A-Z]\d?)\s*\/\s*(\d{2,3})([A-Z]\d?)\b/);
  if (pairMatch) {
    indexedFromName = {
      indeksNosnosci: `${pairMatch[1]}/${pairMatch[3]}`,
      indeksPredkosci: `${pairMatch[2]}/${pairMatch[4]}`
    };
  } else {
    const singleMatch = nameWithoutSize.match(/\b(\d{2,3})([A-Z]\d?)\b/);
    if (singleMatch) {
      indexedFromName = {
        indeksNosnosci: singleMatch[1],
        indeksPredkosci: singleMatch[2]
      };
    }
  }
  // VF/IF/SB/SF/NRO/CHO/CFO/stubble/PR/TL z całej nazwy.
  const allMarks = parseTechnicalMarks(record.name, record.additionalName, record.iloscPlocien);
  const liSiLoad = indexedFromField.indeksNosnosci || indexedFromName.indeksNosnosci;
  const liSiSpeed = indexedFromField.indeksPredkosci || indexedFromName.indeksPredkosci;
  const marks = {
    ...allMarks,
    indeksNosnosci: liSiLoad,
    indeksPredkosci: liSiSpeed
  };

  // === KATEGORIA ===
  // POPRAWKA 2026-06-30: najwyższy priorytet dla pola "Zastosowanie" z CSV.
  // Wcześniej path produktu "Opony rolnicze i przemysłowe/Opony Mitas" wpadał w regex /przemys/
  // → wszystkie Mitas rolnicze trafiały do 'przemyslowe'. Teraz:
  // 1) jeśli Zastosowanie ma wartość — to jest autorytatywne,
  // 2) fallback (bez Zastosowania) NIE używa /przemys/ na cat path (tylko /industrial|loader.../).
  const zastosowanieTxt = cleanText(record.zastosowanie).toLowerCase();
  let kategoria;
  if (zastosowanieTxt) {
    if (/le[s\u015b]n|forest|skidder/.test(zastosowanieTxt)) kategoria = 'le\u015bne';
    else if (/ci[e\u0119]\u017carow|truck/.test(zastosowanieTxt)) kategoria = 'ci\u0119\u017carowe';
    else if (/przemys|industrial/.test(zastosowanieTxt)) kategoria = 'przemys\u0142owe';
    else if (/rolnicz|agric|agro/.test(zastosowanieTxt)) kategoria = 'rolnicze';
  }
  if (!kategoria) {
    const katSource = `${record.category || ''} ${record.name || ''} ${record.additionalName || ''}`.toLowerCase();
    if (/forest|skidder|le[s\u015b]n/.test(katSource)) kategoria = 'le\u015bne';
    else if (/truck|ciezarow|cie\u017carow|3pmsf|drive\b|trailer\b|\bfrt\b/.test(katSource)) kategoria = 'ci\u0119\u017carowe';
    else if (/industrial|loader|grader|compactor|earthmover/.test(katSource)) kategoria = 'przemys\u0142owe';
    // UWAGA: /przemys/ nie jest tu używany, bo path produktu często zawiera "Opony rolnicze i przemysłowe".
    else if (/opona rolnicza|rolnicz|agric|agro|tractor/.test(katSource)) kategoria = 'rolnicze';
    else kategoria = 'rolnicze';
  }
  // Wymuszamy TL dla ciezarowych (decyzja Anny: "Ciezarowe opony zawsze sa TL").
  let tlTtFinal = normalizeTlTt(record.typ) || marks.tlTt;
  if (!tlTtFinal && (kategoria === 'ci\u0119\u017carowe' || kategoria === 'ciezarowe')) tlTtFinal = 'TL';
  const result = {
    odrzucony: false,
    kategoria,
    kodDostawcy: emptyToNull(record.indexCatalogue),
    ean: emptyToNull(record.eanCode),
    marka: producer,
    model,
    rozmiar: size.rozmiar,
    // POPRAWKA 2026-06-30 (v4): rozmiar alternatywny TYLKO z nawiasów + walidacja że to RZECZYWISTĘ RoZMIAR.
    // Decyzja Anny: w Grasdorfie alt-size jest WYŁĄCZNIE w nawiasach w kolumnie "Rozmiar opony"
    // (np. "(300/70-16.5)" lub "(16.9R38)"). Jeśli wartość jest POZA nawiasem — ignorujemy.
    // Walidacja: musi zawierać cyfrę + (R lub - lub /) — inaczej to nie rozmiar (np. "(Quick)" odrzucamy).
    rozmiarAlternatywny: (() => {
      const candidates = [
        record.additionalName?.match(/\(([^)]+)\)/)?.[1],
        record.rozmiarOpony?.match(/\(([^)]+)\)/)?.[1],
        (record.name || '').match(/\(([^)]+)\)/)?.[1]
      ].filter(Boolean).map(s => s.trim());
      for (const c of candidates) {
        // Rozmiar musi mieć formę cyfra(.cyfra)? + (R\d+ | -\d+ | /\d+) — np. "16.9R38", "300/70-16.5", "6.00-12"
        if (/\d+(?:[.,]\d+)?\s*(?:R\s*\d+|-\s*\d+|\/\d+)/i.test(c)) return c;
      }
      return null;
    })(),
    szerokosc: size.szerokosc,
    profil: size.profil,
    srednica: size.srednica,
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    konstrukcja: konstrukcjaTxt.includes('radial') ? 'R' : konstrukcjaTxt.includes('diagonal') ? 'D' : size.konstrukcja,
    indeksNosnosci: marks.indeksNosnosci,
    indeksPredkosci: marks.indeksPredkosci,
    pr: marks.pr || emptyToNull(record.iloscPlocien)?.replace(/\s*PR$/i, ''),
    tlTt: tlTtFinal,
    vfIf: marks.vfIf,
    sb: marks.sb,
    sf: marks.sf,
    nro: marks.nro,
    cho: marks.cho,
    cfo: marks.cfo,
    stubbleResistant: marks.stubbleResistant,
    // POPRAWKA 2026-06-30 (v4): DOT z nazwy LUB additionalName, bez fallbacka "nie starsza niz 3 lata".
    // Decyzja Anny: gdy brak DOT — pole puste w katalogu (nie wpisuj śmieci).
    dot: emptyToNull((record.name || '').match(/\bDOT\s*([0-9]{2,4})\b/i)?.[1])
      || emptyToNull((record.additionalName || '').match(/\bDOT\s*([0-9]{2,4})\b/i)?.[1]),
    stan: normalizeQty(record.availabilityCount),
    cenaZakupu: normalizePrice(record.priceNet),
    linkZdjecia: firstImageUrl(record.imageUrls),
    waga: parseNumber(record.weight),
    dopisek: /\bdemo\b/i.test(record.name || record.indexCatalogue || '') ? 'demo' : /pokazowa/i.test(record.stan || '') ? 'pokazowa' : null
  };
  const liSi = formatLiSi(result.indeksNosnosci, result.indeksPredkosci);
  result.nazwaKoncowa = [
    result.rozmiar,
    result.marka,
    result.model,
    liSi,
    result.pr ? `${result.pr}PR` : null,
    result.tlTt,
    result.dopisek
  ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  return result;
}

function parseHandlopexLoadSpeed(loadRaw, speedRaw) {
  const loadText = cleanText(loadRaw).replace(/[\[\]]/g, '').replace(/\s+/g, '');
  const speedText = emptyToNull(speedRaw);
  const parsed = parseLoadSpeed(loadText);
  if (parsed.indeksNosnosci && parsed.indeksPredkosci) return parsed;
  if (loadText && speedText) {
    const load = loadText.replace(/[A-Z]\d?/gi, '');
    return {
      indeksNosnosci: load || null,
      indeksPredkosci: speedText
    };
  }
  return { indeksNosnosci: loadText || null, indeksPredkosci: speedText || null };
}

// Handlopex: usuwa rozmiar z różnymi wariantami zapisu (ze spacjami i bez)
// Anna 02.07: fixów zdublowanego rozmiaru:
//   - "18x9.50-8 Trelleborg 18 x 9.50 - 8 DRIVER" → "Trelleborg DRIVER"
//   - "13R22.5 Mirage 13 R22.5 MG702" → "Mirage MG702"
// size może być: "315/80R22.5" "18x9.50-8" "13R22.5" "6.00-16"
function removeHandlopexSizeVariants(text, size) {
  if (!size || !text) return text;
  let out = text;
  // Wyciągam liczby z rozmiaru (max 3 liczby: szerokosc, profil, srednica)
  // Konstrukcje: /, R, D, B, x, -
  // Rozkładam size na tokens numeryczne (np. "315/80R22.5" → [315, 80, 22.5])
  const nums = size.match(/\d+(?:\.\d+)?/g) || [];
  if (nums.length < 2) return out;
  // Buduję regex, który akceptuje spacje między liczbami i separatorami
  // Separatory w rozmiarze: /, R, D, B, x, X, - (case-insensitive)
  // np. dla [18, 9.50, 8] chcę wzorca: 18\s*[/RDBx-]\s*9\.50\s*[/RDBx-]\s*8
  const escNums = nums.map(n => n.replace('.', '\\.'));
  const sep = '\\s*[\\/RDBxX-]\\s*';
  let pattern;
  if (nums.length === 2) {
    pattern = `${escNums[0]}${sep}${escNums[1]}`;
  } else {
    pattern = `${escNums[0]}${sep}${escNums[1]}${sep}${escNums[2]}`;
  }
  // (?<![\d.]) i (?![\d.]) zabezpieczają przed łapaniem części innej liczby
  const re = new RegExp(`(?<![\\d.])(?:VF|IF)?\\s*${pattern}(?![\\d.])`, 'gi');
  out = out.replace(re, ' ');
  return out.replace(/\s+/g, ' ').trim();
}

// Anna 02.07: słowa opisowe do usunięcia z modelu i nazwy Handlopex
// Zachowujemy: prowadząca, napęd (info która oś)
// DOT\d{2,4}: rok DOT trafiał do modelu (Anna 02.07 runda 2)
const HANDLOPEX_STOPWORDS_RE = /\b(?:budowlan[ay]|zima|jode[łl]ka|uniwersaln[aey]|steel\s+belted|DOT\s*\d{2,4})\b/gi;

// Anna 02.07 runda 2: usuwa alternatywny/calowy rozmiar w środku nazwy
// Przykłady:
//   "690x180-15 Mitas 7.00 - 15 TS-07" -> usuwa "7.00 - 15"
//   "50/80-12 GTK 6.00-12 BT45" -> usuwa "6.00-12"
//   "13R22.5 Mirage MG702 13-22.5" -> usuwa "13-22.5"
// UWAGA: musi być kreska "-" jako separator (rozmiar calowy), lub kropka w co najmniej jednej liczbie.
// Bez tego žaglibymśmy się na indeksy nośności typu "108A8/105B" ("8/105").
const INCH_ALT_SIZE_RE = /(?<![\d.\/])(?:\d{1,3}\.\d+\s*-\s*\d{1,3}(?:\.\d+)?|\d{1,3}(?:\.\d+)?\s*-\s*\d{1,3}\.\d+|\d{1,3}\.\d+\s*[Rx]\s*\d{1,3}(?:\.\d+)?)(?![\d.\/])/gi;

// Anna 02.07 runda 5: alternatywny rozmiar z konstrukcją literową (L/R/D) po szerokości
//   "19.5L - 24 (500/70 - 24) GRIP-n-RIDE" -> usuwa "19.5L - 24"
//   Uwaga: usuwamy tylko gdy tekst zawiera JUŻ odseparowany główny rozmiar; wywołujemy DOPIERO
//   po removeSizePrefixFromName, więc pozostały alt-size jest bezpiecznie do usunięcia.
const INCH_ALT_SIZE_CONSTR_RE = /(?<![\d.\/])\d{1,3}(?:\.\d+)?[LRD]\s*-\s*\d{1,3}(?:\.\d+)?(?![\d.\/])/gi;

// Anna 02.07 runda 5: standardowe oznaczenia bieżnika TRA/ETRTO do wyciągnięcia do osobnego pola
// R-1..R-4, F-2, F-3, G-1..G-2, I-1..I-3, C-1..C-2, E-2..E-4, L-2..L-5
// Wzorzec: pojedyncza litera z listy + "-" + cyfra [1-5], opcjonalnie "/" + kolejne oznaczenie
// Ważne: NIE łapie T-991/B-19/V-5501 (modele Trelleborg/Mitas) — wymuszona lista liter [RFGICEL].
const TREAD_PATTERN_RE = /\b([RFGICEL])-([1-5])(?:\s*\/\s*([RFGICEL])-([1-5]))?\b/g;

function extractHandlopexModel(nazwa, marka, size) {
  // Anna 02.07: różne warianty rozmiaru (ze spacjami)
  let text = removeSizePrefixFromName(nazwa, size);
  text = removeHandlopexSizeVariants(text, size);
  text = text
    .replace(/\([^)]*\)/g, ' ')
    .replace(/\[[^\]]*\]/g, ' ')
    .replace(HANDLOPEX_STOPWORDS_RE, ' ')  // Anna 02.07: usuwamy budowlana/zima/jodełka/steel belted/DOTxxxx
    .replace(INCH_ALT_SIZE_RE, ' ')         // Anna 02.07 runda 2: usuwa 7.00-15, 6.00-12 itp.
    .replace(INCH_ALT_SIZE_CONSTR_RE, ' ')  // Anna 02.07 runda 5: usuwa 19.5L-24, 12.5/80-18 itp.
    .replace(/\b\d{1,2}\s*PR\b/gi, ' ')
    .replace(/\bTL\b|\bTT\b|\bM\+S\b|\b3PMSF\b|\bNEW\b/gi, ' ')
    // Anna 02.07 runda 4: NIE ruszaj samotnych liter jeśli po nich jest '-N' (oznaczenie bieżnika)
    // Anna 02.07 runda 5: rozszerzenie na wielocyfrowe N — chronimy litery przed:
    //   R-4, G-2, C-1, E-3, L-3, I-3 (bieżnik, jednocyfrowe)
    //   T-991, T-539, T-421, T-510 (Trelleborg)
    //   B-11, B-15, B-16, B-19, B-63 (Mitas)
    //   V-5501 (Mitas)
    .replace(/\b[A-Z]\d?\b(?!\s*-\s*\d+\b)/g, ' ')
    // Anna 02.07 runda 3: usuwamy ukośnik przed prowadząca/napęd ("/prowadząca" → "prowadząca")
    .replace(/\/\s*(prowadząca|napęd)\b/gi, '$1')
    // Anna 02.07 runda 3/4: "-N" (N=1..5) → "R-N" (oznaczenie bieżnika)
    // Warunek: minus poprzedzony SPACJĄ/początkiem (nie literą — wtedy zostawiamy G-2, C-1 itp.)
    // Regex: (^|\s)- + lookahead cyfra 1..5 + granica słowa
    .replace(/(^|\s)-(?=[1-5]\b)/g, '$1R-')
    // Sprzątanie po usuwaniu: wiszące ukosłłniki np. "MG011 / " → "MG011"
    .replace(/\s*\/\s*(?=\s|$)/g, ' ')
    .replace(/\s+\/\s+/g, ' ')
    // Anna 02.07 runda 2: osierocone kropki po liczbie ("GTK 6. BT45" → "GTK BT45")
    .replace(/\b\d+\.\s+/g, ' ')
    .trim();
  if (marka) text = text.replace(new RegExp(`\\b${marka.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'ig'), ' ');

  // Anna 02.07 runda 5: wyciągamy oznaczenia bieżnika (R-4, G-2, E-3/L-3, C-1, L-2, itp.) do osobnego pola
  const treads = [];
  text = text.replace(TREAD_PATTERN_RE, (match, l1, n1, l2, n2) => {
    if (l2 && n2) {
      treads.push(`${l1}-${n1}/${l2}-${n2}`);
    } else {
      treads.push(`${l1}-${n1}`);
    }
    return ' ';
  });
  const oznaczenieBieznika = treads.length ? treads.join(' ') : null;

  const model = text.replace(/\s+/g, ' ').trim() || null;
  return { model, oznaczenieBieznika };
}

// POPRAWKA 2026-07-17 (Handlopex, Anna): PODWOJNY ROZMIAR w nazwie bez nawiasu, np.
// "4.00 - 8 / 4.80 - 8  MIM 374 R1". To dwa rownowazne rozmiary (podwojne oznaczenie)
// sklejone " / ", NIE metryczno-calowy odpowiednik w nawiasie (ten obslugujemy osobno,
// zostawiajac pierwszy czlon). Tu bierzemy PIERWSZY pelny rozmiar i USUWAMY resztê przed
// modelem, zeby fragment "4.80 - 8" nie wpadl do rozmiaru ani do modelu. Warunek scisly:
// oba czlony to kompletne rozmiary calowe "D.DD - D" / "D - D" na POCZATKU nazwy, rozdzielone
// " / ", i przed dopasowaniem NIE ma otwierajacego nawiasu (chroni wzorzec nawiasowy).
function stripDualSize(nazwa) {
  if (!nazwa) return nazwa;
  // Jesli tuz na poczatku jest nawias — to wzorzec metryczno-calowy "SIZE (SIZE)",
  // nie ruszamy (obslugiwany osobno). Sprawdzamy tylko poczatek nazwy.
  const paren = nazwa.indexOf('(');
  if (paren !== -1 && paren < 25) return nazwa;
  const m = nazwa.match(/^\s*(\d{1,3}(?:[.,]\d+)?\s*-\s*\d{1,3}(?:[.,]\d+)?)\s*\/\s*\d{1,3}(?:[.,]\d+)?\s*-\s*\d{1,3}(?:[.,]\d+)?\s+(.*)$/);
  if (!m) return nazwa;
  // m[1] = pierwszy pelny rozmiar, m[2] = reszta nazwy (model + oznaczenia) po drugim rozmiarze
  return `${m[1]} ${m[2]}`;
}

function normalizeHandlopex(record) {
  const sizeRaw = `${record.szerokosc || ''}/${record.profil || ''}R${record.srednica || ''}`;
  // POPRAWKA 2026-07-17: nazwa oczyszczona z podwojnego rozmiaru uzywana do rozmiaru i modelu.
  const nazwaClean = stripDualSize(record.nazwa);
  const nameSize = parseSize(nazwaClean);
  const fallbackSize = parseSize(sizeRaw);
  const size = nameSize.rozmiar ? nameSize : fallbackSize;
  const loadSpeed = parseHandlopexLoadSpeed(record.indeksNosnosci, record.indeksPredkosci);
  const marks = parseTechnicalMarks(record.nazwa);
  const marka = emptyToNull(record.producent);
  // Anna 02.07 runda 5: extractHandlopexModel zwraca teraz obiekt {model, oznaczenieBieznika}
  const { model, oznaczenieBieznika } = extractHandlopexModel(nazwaClean, marka, size.rozmiar);
  // Anna 02.07: Steel Belted → flaga sb=1 + skrót "SB" w nazwie
  const sb = /\bsteel\s+belted\b/i.test(record.nazwa || '') ? 1 : 0;
  const simpleInchSize = !!(size.rozmiar && /^\d{1,3}(?:\.\d+)?-\d{1,3}(?:\.\d+)?$/.test(size.rozmiar));
  const result = {
    kategoria: record.kategoria || (/16PR|AWE 713|SET/i.test(record.nazwa || '') ? 'przemys\u0142owe' : /R\d{2}\.5|M\+S|3PMSF/i.test(record.nazwa || '') ? 'ci\u0119\u017carowe' : 'rolnicze'),
    kodDostawcy: emptyToNull(record.symbolHandlopex),
    ean: emptyToNull(record.ean),
    marka,
    model,
    oznaczenieBieznika,  // Anna 02.07 runda 5: R-4, G-2, E-3/L-3 itp. do osobnej kolumny
    rozmiar: size.rozmiar,
    // POPRAWKA 2026-07-17 (Handlopex): szerokosc/profil/srednica bierzemy z ROZBICIA
    // rozmiaru (size.*), a nie z surowych kolumn CSV Handlopex. Kolumny te dla opon
    // calowych/MRL zawieraly fragmenty tekstu ("23 x 10", "4.00", "6.50") lub domyslny
    // profil=82, co dawalo bledne szerokosci (2310, 4, 1270) i profil. size.* pochodzi
    // z parseSize(rozmiar) i jest spojne z wymiarami liczonymi w tire_dims. Fallback do
    // kolumn tylko gdy rozbicie rozmiaru nie dalo wartosci.
    szerokosc: size.szerokosc ?? parseNumber(record.szerokosc),
    profil: simpleInchSize ? null : (size.profil ?? parseNumber(record.profil)),
    srednica: size.srednica ?? parseNumber(record.srednica),
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    konstrukcja: size.konstrukcja,
    indeksNosnosci: loadSpeed.indeksNosnosci,
    indeksPredkosci: loadSpeed.indeksPredkosci,
    pr: marks.pr,
    tlTt: marks.tlTt,
    ms: /\bM\+S\b/i.test(record.nazwa || '') ? 1 : 0,
    snow3pmsf: /\b3PMSF\b/i.test(record.nazwa || '') ? 1 : 0,
    labelRolling: emptyToNull(record.oporToczenia),
    labelWet: emptyToNull(record.przyczepnosc),
    labelNoise: emptyToNull(record.halas),
    labelNoiseClass: emptyToNull(record.labelNoise),
    labelSnow: normalizeQty(record.labelSnow) ?? 0,
    labelIce: normalizeQty(record.labelIce) ?? 0,
    dot: emptyToNull(record.dot) || 'nie starsza niz 3 lata',
    waga: parseNumber(record.waga),
    stan: normalizeQty(record.ilosc),
    cenaZakupu: normalizePrice(record.cenaHurtNetto),
    sb,  // Anna 02.07: flaga Steel Belted → kolumna sb
    dopisek: null
  };
  const liSi = formatLiSi(result.indeksNosnosci, result.indeksPredkosci);
  result.nazwaKoncowa = [
    result.rozmiar,
    result.marka,
    result.model,
    result.oznaczenieBieznika,  // Anna 02.07 runda 5: R-4, G-2, E-3/L-3 itp. w nazwie po modelu
    liSi,
    result.pr ? `${result.pr}PR` : null,
    result.tlTt,
    result.ms ? 'M+S' : null,
    result.snow3pmsf ? '3PMSF' : null,
    result.sb ? 'SB' : null,  // Anna 02.07: skrót SB w nazwie
    result.dopisek
  ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  return result;
}

function normalizeAgrowiec(record) {
  const size = parseSize(record.rozmiar);
  const loadSpeed = parseLoadSpeed(record.indeksy);
  const vfIf = emptyToNull(record.vfIf);
  const result = {
    kategoria: cleanText(record.kategoria).toLowerCase() || null,
    kodDostawcy: null,
    ean: emptyToNull(record.ean),
    marka: emptyToNull(record.producent),
    model: emptyToNull(record.model),
    rozmiar: size.rozmiar,
    szerokosc: size.szerokosc,
    profil: size.profil,
    srednica: size.srednica,
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    konstrukcja: size.konstrukcja,
    indeksNosnosci: loadSpeed.indeksNosnosci,
    indeksPredkosci: loadSpeed.indeksPredkosci,
    vfIf,
    tlTt: null,
    pr: null,
    dot: 'nie starsza niz 3 lata',
    stan: normalizeQty(record.stan),
    cenaZakupu: normalizePrice(record.cena)
  };
  const liSi = formatLiSi(result.indeksNosnosci, result.indeksPredkosci);
  const sizeForName = vfIf ? `${vfIf}${result.rozmiar}` : result.rozmiar;
  result.nazwaKoncowa = [sizeForName, result.marka, result.model, liSi].filter(Boolean).join(' ').trim();
  return result;
}

function stripBrandFromModel(model, brand) {
  let text = cleanText(model);
  if (!text) return null;
  if (brand) {
    text = text.replace(new RegExp(`\\b${brand.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'ig'), ' ');
  }
  text = text.replace(/\bTyres\b/gi, ' ').replace(/\bSB\b|\bSF\b/gi, ' ');
  return text.replace(/\s+/g, ' ').trim() || null;
}

function normalizeNokian(record) {
  const size = parseSize(record.rozmiar);
  const loadSpeed = parseLoadSpeed(record.liSi);
  const marka = emptyToNull(record.producent);
  const model = stripBrandFromModel(record.model || record.bieznik, marka);
  const sbSf = cleanText(record.sfSb).toUpperCase();
  const result = {
    kategoria: /rolnicz/i.test(record.rodzaj || '') ? 'rolnicze' : cleanText(record.rodzaj).toLowerCase() || null,
    kodDostawcy: emptyToNull(record.kodProduktu),
    ean: emptyToNull(record.ean),
    marka,
    model,
    rozmiar: size.rozmiar,
    rozmiarAlternatywny: emptyToNull(record.rozmiarAlternatywny),
    szerokosc: size.szerokosc,
    profil: size.profil,
    srednica: size.srednica,
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    konstrukcja: size.konstrukcja,
    indeksNosnosci: loadSpeed.indeksNosnosci,
    indeksPredkosci: loadSpeed.indeksPredkosci,
    sb: sbSf === 'SB' ? 1 : null,
    sf: sbSf === 'SF' ? 1 : null,
    tlTt: emptyToNull(record.tlTt),
    pr: emptyToNull(record.pr)?.replace(/\s*PR$/i, '') || null,
    dot: 'nie starsza niz 3 lata',
    stan: normalizeQty(record.magazyn),
    cenaZakupu: normalizePrice(record.zakup1)
  };
  const liSi = formatLiSi(result.indeksNosnosci, result.indeksPredkosci);
  result.nazwaKoncowa = [
    result.rozmiar,
    result.marka,
    result.model,
    liSi,
    result.sb ? 'SB' : result.sf ? 'SF' : null,
    result.pr ? `${result.pr}PR` : null,
    result.tlTt
  ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  return result;
}

function normalizeScientificEan(value) {
  const raw = cleanText(value);
  if (!raw) return null;
  if (!/[eE]/.test(raw)) return raw.replace(/\D/g, '') || raw;
  const normalized = raw.replace(',', '.');
  const num = Number(normalized);
  if (!Number.isFinite(num)) return raw;
  return Math.trunc(num).toString();
}

function normalizeTrelleborg(record) {
  const size = parseSize(record.rozmiar);
  const loadSpeed = parseLoadSpeed(record.liSi);
  const vfIf = emptyToNull(record.vfIf);
  const cfo = emptyToNull(record.cfo) ? 1 : 0;
  const result = {
    kategoria: cleanText(record.rodzaj).toLowerCase() || null,
    kodDostawcy: emptyToNull(record.kodProducenta),
    ean: normalizeScientificEan(record.ean),
    marka: emptyToNull(record.producent),
    model: emptyToNull(record.bieznik),
    rozmiar: size.rozmiar,
    rozmiarAlternatywny: emptyToNull(record.rozmiarAlternatywny),
    szerokosc: size.szerokosc,
    profil: size.profil,
    srednica: size.srednica,
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    konstrukcja: size.konstrukcja,
    indeksNosnosci: loadSpeed.indeksNosnosci,
    indeksPredkosci: loadSpeed.indeksPredkosci,
    pr: emptyToNull(record.pr)?.replace(/\s*PR$/i, '') || null,
    vfIf,
    cfo,
    tlTt: emptyToNull(record.tlTt),
    dot: 'nie starsza niz 3 lata',
    stan: normalizeQty(record.magazyn),
    cenaZakupu: normalizePrice(record.cena)
  };
  const liSi = formatLiSi(result.indeksNosnosci, result.indeksPredkosci);
  const sizeForName = vfIf ? `${vfIf}${result.rozmiar}` : result.rozmiar;
  result.nazwaKoncowa = [
    sizeForName,
    cfo ? 'CFO' : null,
    result.marka,
    result.model,
    liSi,
    result.pr ? `${result.pr}PR` : null,
    result.tlTt
  ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  return result;
}

function normalizeAgrorami(record) {
  const size = parseSize(record.rozmiar);
  const loadRaw = emptyToNull(record.nosnosc);
  const speedRaw = emptyToNull(record.predkosc);
  const loadParts = loadRaw ? loadRaw.replace(/\s+/g, '').split('/') : [];
  const speedParts = speedRaw ? speedRaw.replace(/\s+/g, '').split('/') : [];
  const parsedLiSi = parseLoadSpeed(`${record.nosnosc || ''}${record.predkosc || ''}`);
  const load = loadParts.length ? loadParts.join('/') : parsedLiSi.indeksNosnosci || loadRaw;
  const speed = speedParts.length
    ? (loadParts.length > 1 && speedParts.length === 1 ? loadParts.map(() => speedParts[0]).join('/') : speedParts.join('/'))
    : parsedLiSi.indeksPredkosci || speedRaw;
  // POPRAWKA 2026-06-22: ekstrakcja oznaczen technicznych z biegnika, producenta i
  // rozmiaru. Wczesniej Agrorami w ogole nie wyciagal VF/IF/SB/SF/CFO/NRO/CHO/stubble
  // — np. "500/85R24 BKT RM 500 (steel belted) 182A8/170A8 TL" gubilo SB. Bieznik
  // czesto zawiera te oznaczenia w kontekscie (np. "(steel belted)", "VF", "CFO").
  const marks = parseTechnicalMarks(record.bieznik, record.producent, record.rozmiar);
  // POPRAWKA 2026-06-22 v2: kategoria fallback dla "inne" w Agrorami.
  // Wczesniej wszystkie "inne" -> rolnicze (~209 wierszy MO9 zle sklasyfikowanych).
  // Teraz po bezniku rozpoznajemy:
  //  - lesne: forest/skidder/lesn
  //  - ciezarowe: truck/3pmsf
  //  - przemyslowe: loader/forklift/skid steer/port/industrial markery
  //  - rolnicze: pozostale
  const katRaw = cleanText(record.kategoria).toLowerCase();
  let kategoria;
  if (!katRaw || katRaw === 'inne') {
    const txt = `${record.bieznik || ''} ${record.producent || ''} ${record.rozmiar || ''}`.toLowerCase();
    // Przemyslowe: wozki widlowe, loadery, skid steer, kompaktory, portowe
    const reIndustrial = /\b(maglift|liftmax|lift\s*max|loader|con\s*star|earthmax|skid\s*power|pac\s*master|pacmaster|trac\s*master|rock\s*grip|giant\s*trax|jumbotrax|suretrax|bk-?loader|gr\s*288|xl\s*grip|v-line|pl\s*801|pt\s*-?\s*hd|lg\s*30[68]|lg\s*408|multimax|mp\s*5[1-9]\d|mp\s*[56]00|rib\s*774|sp\s*imp|airomax|am27|as\s*(504|509|2001)|aw\s*(70[258]|909)|at\s*(111|621)|fs\s*216|tf\s*(8181|9090)|ind\b|imp\b|port\b)/i;
    if (/forest|skidder|le[sś]n/.test(txt)) kategoria = 'le\u015bne';
    else if (/truck|ciezarow|cie\u017carow|3pmsf/.test(txt)) kategoria = 'ci\u0119\u017carowe';
    else if (reIndustrial.test(txt)) kategoria = 'przemys\u0142owe';
    else kategoria = 'rolnicze';
  } else {
    kategoria = katRaw;
  }
  let tlTt = normalizeTlTt(record.tlTt) || marks.tlTt;
  if (!tlTt && (kategoria === 'ciezarowe' || kategoria === 'ci\u0119\u017carowe')) tlTt = 'TL';
  const result = {
    kategoria,
    // NAPRAWIONE 2026-07-13: kodDostawcy MUSI pochodzic z record.kod_dostawcy (ktore
    // mo9_agrorami_api.cjs ustawia teraz na `sku`, prawdziwy kod handlowy Agrorami),
    // NIE z record.id (wewnetrzny numeryczny identyfikator encji Magento). record.id
    // jest zachowany tylko jako fallback techniczny, gdy kod_dostawcy jest puste.
    kodDostawcy: emptyToNull(record.kod_dostawcy) || emptyToNull(record.id),
    // idStabilny: identyfikator UZYWANY WYLACZNIE do budowy products.kod (PRIMARY KEY,
    // nie wolno mu sie zmieniac przy kolejnych synchronizacjach). Zostaje na Magento
    // entity_id (record.id), zeby zmiana kodDostawcy (id->sku, 2026-07-13) NIE powodowala
    // przeliczenia PK istniejacych produktow (co lamaloby dopasowanie przy synchronizacji).
    idStabilny: emptyToNull(record.id),
    ean: emptyToNull(record.ean),
    marka: emptyToNull(record.producent),
    model: emptyToNull(record.bieznik),
    rozmiar: size.rozmiar,
    szerokosc: size.szerokosc,
    profil: size.profil,
    srednica: size.srednica,
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    konstrukcja: size.konstrukcja,
    // POPRAWKA 2026-07-10 (decyzja Anny): usunięto fallback na marks.indeksNosnosci/
    // marks.indeksPredkosci (z parseTechnicalMarks(bieznik, producent, rozmiar)).
    // Ten fallback łączy bieznik+producent+rozmiar w jeden tekst i przepuszcza przez
    // parseLoadSpeed() — dla API Agrorami (które teraz dostaje bieznik/rozmiar z
    // parseAgroramiName(), CZYSTE, bez LI/SI w tekście) to łapało fałszywe dopasowania
    // z cyfr modelu+rozmiaru, np. "EM 936"+"8.25x20" → "936/25" jako fałszywy LI/SI.
    // Zweryfikowane (2026-07-10): TYLKO normalizeAgrorami używa tego fallbacku w ten
    // sposób (load||marks.X) — inne 5 dostawców (JMK/Grasdorf/Handlopex/GRI/Bohnenkamp)
    // mają własne, dedykowane ścieżki LI/SI i NIE korzystają z marks.indeksNosnosci/
    // marks.indeksPredkosci w finalnym wyniku — usunięcie tego fallbacku dotyka
    // wyłącznie Agrorami, 0 ryzyka regresji dla pozostałych dostawców.
    // Gdy nosnosc/predkosc są puste (opona faktycznie nie ma LI/SI w nazwie, np. opony
    // przemysłowe typu "EM 936"), indeksNosnosci/indeksPredkosci poprawnie wychodzą null.
    indeksNosnosci: load,
    indeksPredkosci: speed,
    pr: emptyToNull(record.plotna) || marks.pr,
    tlTt,
    vfIf: marks.vfIf,
    sb: marks.sb,
    sf: marks.sf,
    nro: marks.nro,
    cho: marks.cho,
    cfo: marks.cfo,
    stubbleResistant: marks.stubbleResistant,
    dot: 'nie starsza niz 3 lata',
    waga: parseNumber(record.waga),
    sezon: emptyToNull(record.sezon),
    stan: normalizeQty(record.magazyn),
    cenaZakupu: normalizePrice(record.cena)
  };
  const liSi = formatLiSi(load, speed);
  result.nazwaKoncowa = [
    result.rozmiar,
    result.marka,
    result.model,
    liSi,
    result.pr ? `${result.pr}PR` : null,
    result.tlTt
  ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  return result;
}

function extractTreadDesignation(value) {
  const text = cleanText(value).toUpperCase();
  const match = text.match(/\b([RILEGC])-?\s*(\d)([SW])?\b/);
  if (!match) return null;
  return `${match[1]}-${match[2]}${match[3] || ''}`;
}

// POPRAWKA 2026-06-30: detekcja opon przemysłowych (NHS/widłowe/budowlane).
// Klucz: w oponach NHS liczba przed literą ("5.00-8 10 IND TTF") NIE jest LI/SI,
// tylko PR. Litera "I" z "IND" nie jest indeksem prędkości.
const GRI_INDUSTRIAL_SIZE_RE = /^(\d(?:\.\d+)?)\.\d{2}[-x]\d{1,2}$|^\d{1,2}x\d(?:\.\d+)?(?:-\d{1,2})?$/i;
const GRI_INDUSTRIAL_NAME_RE = /\bLIFT\b|\bFORK(?:LIFT)?\b|\bIND(?:USTRIAL)?\b|\bNHS\b|\bSOLID(?:EAL)?\b|\bSKID[\s-]?STEER\b|\bRESILIENT\b/i;

function isGriIndustrial(rozmiar, fullSpec, bieznik) {
  if (rozmiar && GRI_INDUSTRIAL_SIZE_RE.test(rozmiar)) return true;
  if (fullSpec && GRI_INDUSTRIAL_NAME_RE.test(fullSpec)) return true;
  if (bieznik && GRI_INDUSTRIAL_NAME_RE.test(bieznik)) return true;
  return false;
}

function normalizeGri(record) {
  const spec = cleanText(record.rozmiar || record.spec || record.opis);
  const bieznik = cleanText(record.model || record.bieznik || '');
  const fullSpec = `${bieznik} ${spec}`.trim();
  const size = parseSize(spec);
  const marks = parseTechnicalMarks(spec);
  const tread = extractTreadDesignation(spec);

  // POPRAWKA 2026-06-30: detekcja opon przemysłowych przed dalszą analizą
  const industrial = isGriIndustrial(size.rozmiar, fullSpec, bieznik);

  // POPRAWKA 2026-06-30: TTF (Tube Type with Flap) → traktujemy jak TT
  const upperSpec = fullSpec.toUpperCase();
  let tlTt = marks.tlTt;
  if (!tlTt && /\bTTF\b/.test(upperSpec)) tlTt = 'TT';

  let indeksNosnosci = null;
  let indeksPredkosci = null;
  let pr = marks.pr;

  if (industrial) {
    // POPRAWKA 2026-06-30: w oponach NHS "5.00-8 10 IND TTF" liczba 10 to PR,
    // a następna litera ("I" z "IND") to NIE indeks prędkości.
    // PR znajdujemy jako 1–3 cyfry przed IND/NHS/PR lub przed TT/TL/TTF.
    if (!pr) {
      // "5.00-8 10 IND TTF" → PR=10
      const m1 = upperSpec.match(/\b(\d{1,3})\s+(?:IND|NHS|FORK|LIFT)\b/);
      if (m1) pr = m1[1];
    }
    if (!pr) {
      // "5.00-8 10 TTF" / "5.00-8 10 TT" → PR=10
      const m2 = upperSpec.match(/\b(\d{1,3})\s+(?:TTF|TT|TL)\b/);
      if (m2) pr = m2[1];
    }
    // Żadne LI/SI dla opon przemysłowych
  } else {
    // POPRAWKA 2026-07-01 (v8 GRI): rozmiar imperialny "31X15.5-15" (wielkie X) w oryginalnym
    // spec-u nie pasował do size.rozmiar który parseSize normalizuje na "31x15.5-15" (małe x).
    // Skutek: replace nie znajdował rozmiaru, indexSource nadal zawierał "31X15.5-15",
    // parseLoadSpeed łapał "31X1" jako indeks nośności/prędkości.
    // Fix: budujemy case-insensitive wzorzec z size.rozmiar zamiast literalnego replace.
    //
    // POPRAWKA 2026-07-01 (v9 GRI): dla rozmiaru metrycznego ("420/85R28") oryginalny
    // spec w pliku GRI ma spacje: "420/85 R28 139D R1W TL". parseSize normalizuje do
    // "420/85R28" (bez spacji), ale surowy spec spacje zachowuje — więc replace nie
    // znajdował rozmiaru i indexSource nadal zawierał "420/85 R28 139D". parseLoadSpeed
    // łapał wtedy "85R2" (LI=85, SI=R2) z fragmentu "85 R28" jako fałszywą pierwszą parę
    // LI/SI, a "139D" jako drugą. Fix: normalizujemy indexSource tak samo jak parseSize
    // (spacje w \d R \d, \d - \d, \d B \d, \d x \d) PRZED replace rozmiaru.
    let indexSource = spec
      .replace(/(\d)\s+([RBD])\s*(\d)/gi, '$1$2$3')
      .replace(/(\d)\s*-\s*(\d)/g, '$1-$2')
      .replace(/(\d)\s*x\s*(\d)/gi, '$1x$2')
      .replace(/\s*\/\s*/g, '/');
    if (size.rozmiar) {
      const escaped = size.rozmiar.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      indexSource = indexSource.replace(new RegExp(escaped, 'i'), ' ');
    }
    indexSource = indexSource
      .replace(/\b\d{1,2}\s*PR\b/gi, ' ')
      .replace(/\b[RILEGC]-?\s*\d[SW]?\b/gi, ' ')
      .replace(/\bTL\b|\bTT\b|\bTTF\b/gi, ' ');
    const loadSpeed = parseLoadSpeed(indexSource);
    indeksNosnosci = loadSpeed.indeksNosnosci;
    indeksPredkosci = loadSpeed.indeksPredkosci;
  }

  // POPRAWKA 2026-07-01 (v10 GRI): opony o wysokiej nośności mają prefix VF/IF przed rozmiarem.
  // W pliku GRI model "GREEN XLR vFLEX ..." => VF, model "GREEN XLR iFLEX ..." => IF.
  // Dodatkowo surowe pole Rozmiar czasem zawiera literalny "VF "/"IF " (fallback).
  let sizePrefix = '';
  const bieznikUpper = (bieznik || '').toUpperCase();
  const specUpper = (spec || '').toUpperCase();
  if (/\bVFLEX\b/i.test(bieznikUpper) || /^\s*VF\s+\d/.test(specUpper)) {
    sizePrefix = 'VF';
  } else if (/\bIFLEX\b/i.test(bieznikUpper) || /^\s*IF\s+\d/.test(specUpper)) {
    sizePrefix = 'IF';
  }
  const rozmiarZPrefiksem = size.rozmiar ? `${sizePrefix}${size.rozmiar}` : size.rozmiar;

  const result = {
    kategoria: industrial ? 'przemys\u0142owe' : (tread && /^[ILEGC]-/.test(tread) ? 'przemys\u0142owe' : 'rolnicze'),
    kodDostawcy: emptyToNull(record.kodDostawcy || record.nrKat),
    ean: emptyToNull(record.ean),
    marka: 'GRI',
    model: emptyToNull(record.model || record.bieznik),
    rozmiar: rozmiarZPrefiksem,
    szerokosc: size.szerokosc,
    profil: size.profil,
    srednica: size.srednica,
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    konstrukcja: size.konstrukcja,
    indeksNosnosci,
    indeksPredkosci,
    pr,
    tlTt,
    oznaczenieBieznika: tread,
    dot: 'nie starsza niz 3 lata',
    stan: normalizeQty(record.stan || record.ilosc),
    cenaZakupu: normalizePrice(record.cena)
  };
  // POPRAWKA 2026-06-30: dla opon przemysłowych w nazwie zamiast LI/SI dajemy PR
  const liSi = industrial ? null : formatLiSi(result.indeksNosnosci, result.indeksPredkosci);
  result.nazwaKoncowa = [
    result.rozmiar,
    result.marka,
    result.model,
    liSi,
    result.pr ? `${result.pr}PR` : null,
    result.oznaczenieBieznika,
    result.tlTt
  ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  return result;
}

function removeSizePrefixFromName(name, size) {
  let text = cleanText(name)
    .replace(/^Opona\s+/i, '')
    .replace(/\([^)]*szt\.[^)]*\)/i, '')
    .replace(/,\s*/g, ' ')
    .trim();
  if (size) {
    const sizePattern = size.match(/^(\d+(?:\.\d+)?)\/(\d+(?:\.\d+)?)([RBD-])(\d+(?:\.\d+)?)$/i);
    if (sizePattern) {
      const [, w, p, k, d] = sizePattern;
      const rough = `${w}\\s*\\/\\s*${p}\\s*${k === '-' ? '[-]' : k}\\s*${d}`;
      text = text.replace(new RegExp(`\\b(?:VF|IF)?\\s*${rough}\\b`, 'i'), ' ');
    } else {
      const rough = size.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/-/g, '\\s*-\\s*');
      text = text.replace(new RegExp(`(?<![\\d.])${rough}(?![\\d.])`, 'i'), ' ');
    }
  }
  return text.replace(/\s+/g, ' ').trim();
}

function extractModelFromBohnenkamp(name, size) {
  const comma = cleanText(name).split(',');
  if (comma.length > 1) return comma.slice(1).join(',').trim() || null;
  const rest = removeSizePrefixFromName(name, size);
  const withoutMarks = rest
    .replace(/\bNRO\b/gi, '')
    .replace(/\bCFO\b/gi, '')
    .replace(/\bCHO\b/gi, '')
    .trim();
  return withoutMarks || null;
}

// POPRAWKA 2026-07-01: gdy nazwa Bohnenkamp nie zawiera modelu (np. "OPONA 6.50 - 16"),
// próbujemy wyłuskać model z pola specyfikacji — tam czasem siedzi "YARDMASTER ULTRA",
// "FARMPRO 303" itp. za tokenami PR/TT/TL. Filtrujemy techniczne tokeny.
function extractModelFromBohnenkampSpec(spec) {
  if (!spec) return null;
  const s = cleanText(spec);
  if (!s) return null;
  // Rozbij przecinkami
  const parts = s.split(/[,;]+/).map(p => p.trim()).filter(Boolean);
  // Filtry: tokeny do wyrzucenia (techniczne markery i indeksy)
  const kept = parts.filter(part => {
    const p = part.trim();
    if (!p) return false;
    // Same PR/TT/TL/TT-TL/M+S itd.
    if (/^\d{1,2}\s*PR$/i.test(p)) return false;
    if (/^(TL|TT|TL\s*\/\s*TT|TT\s*\/\s*TL)$/i.test(p)) return false;
    if (/^(NRO|CFO|CHO|SB|SF|VF|IF|BSW)$/i.test(p)) return false;
    if (/^(Steel\s*Belted|Stubble\s*Guard|Stubble\s*Resistant|MPT)$/i.test(p)) return false;
    // Indeksy nośności/prędkości: 158 B, 118 A8 / 130 A8, 91 P itd.
    if (/^\d{2,3}\s*[A-Z]\d?(\s*\/\s*\d{2,3}\s*[A-Z]\d?)*$/i.test(p)) return false;
    // Sam pojedynczy indeks prędkości (D/G/A8...)
    if (/^[A-Z]\d?$/i.test(p)) return false;
    return true;
  });
  const joined = kept.join(' ').replace(/\s+/g, ' ').trim();
  return joined || null;
}

function buildTyreName(parts) {
  const sizeForName = parts.vfIf ? `${parts.vfIf}${parts.rozmiar}` : parts.rozmiar;
  const liSi = parts.indeksNosnosci && parts.indeksPredkosci
    ? parts.indeksNosnosci.split('/').map((li, idx) => `${li}${parts.indeksPredkosci.split('/')[idx] || parts.indeksPredkosci}`).join('/')
    : null;
  const tech = [
    parts.nro ? 'NRO' : null,
    parts.cho ? 'CHO' : null,
    parts.cfo ? 'CFO' : null,
    parts.sb ? 'SB' : null,
    parts.sf ? 'SF' : null,
    parts.stubbleResistant ? 'Stubble Guard' : null
  ].filter(Boolean);
  return [
    sizeForName,
    ...tech.filter(x => ['NRO', 'CHO', 'CFO'].includes(x)),
    parts.marka,
    parts.model,
    liSi,
    parts.pr ? `${parts.pr}PR` : null,
    ...tech.filter(x => !['NRO', 'CHO', 'CFO'].includes(x)),
    parts.tlTt
  ].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
}

function normalizeBohnenkamp(row) {
  const [
    kodDostawcy,
    ean,
    producent,
    nazwa,
    spec,
    producent2,
    _flag,
    cena,
    stanKolumna,
    _ignored,
  ] = row;
  const cleanName = cleanText(nazwa);
  const isTube = /d[ęe]tka/i.test(cleanName);
  const sztMatch = cleanName.match(/\(szt\.?\s*(\d+)\)/i);
  const size = parseSize(cleanName);
  const marks = {
    ...parseTechnicalMarks(spec),
    vfIf: parseTechnicalMarks(cleanName).vfIf || parseTechnicalMarks(spec).vfIf,
    nro: parseTechnicalMarks(cleanName).nro || parseTechnicalMarks(spec).nro,
    cho: parseTechnicalMarks(cleanName).cho || parseTechnicalMarks(spec).cho,
    cfo: parseTechnicalMarks(cleanName).cfo || parseTechnicalMarks(spec).cfo,
    stubbleResistant: parseTechnicalMarks(cleanName).stubbleResistant || parseTechnicalMarks(spec).stubbleResistant
  };

  if (isTube) {
    const alt = cleanText(row[5]).match(/\(([^)]+)\)/g) || [];
    const altSizes = alt.map(v => v.replace(/[()]/g, '').trim()).filter(Boolean);
    const valve = emptyToNull(spec);
    return {
      kategoria: 'detki',
      kodDostawcy: emptyToNull(kodDostawcy),
      ean: emptyToNull(ean),
      marka: emptyToNull(producent || producent2),
      typ: 'Detka',
      rozmiar: size.rozmiar,
      rozmiarAlternatywny: altSizes.join('; ') || null,
      wentyl: valve,
      stan: sztMatch ? Number.parseInt(sztMatch[1], 10) : null,
      cenaZakupu: normalizePrice(cena),
      nazwaKoncowa: ['Detka', size.rozmiar, emptyToNull(producent || producent2), valve].filter(Boolean).join(' ')
    };
  }

  let model = extractModelFromBohnenkamp(cleanName, size.rozmiar);
  // POPRAWKA 2026-07-01: jesli nie ma modelu w nazwie (np. "OPONA 6.50 - 16"),
  // szukaj w spec (np. "6 PR , TT ,FARMPRO 303" -> "FARMPRO 303").
  if (!model) {
    model = extractModelFromBohnenkampSpec(spec);
  }

  // POPRAWKA 2026-07-01: klasyfikacja kategorii z uwzględnieniem modelu — rozpoznaje
  // Forestar/Forestry/Forstech/Agroforestry jako leśne. Dotychczas było hardkodowane 'rolnicze'.
  const textDoKlasyfikacji = [cleanName, model, spec].filter(Boolean).join(' ');
  const kategoriaDetected = commonHelpers.classifyByName(textDoKlasyfikacji, size.rozmiar);
  const result = {
    kategoria: kategoriaDetected || 'rolnicze',
    kodDostawcy: emptyToNull(kodDostawcy),
    ean: emptyToNull(ean),
    marka: emptyToNull(producent || producent2),
    model,
    rozmiar: size.rozmiar,
    szerokosc: size.szerokosc,
    profil: size.profil,
    srednica: size.srednica,
    konstrukcja: size.konstrukcja,
    wysokoscRzeczywistaCm: size.wysokoscRzeczywistaCm,
    wysokoscBokuCm: size.wysokoscBokuCm,
    ...marks,
    dot: 'nie starsza niz 3 lata',
    stan: normalizeQty(stanKolumna),
    cenaZakupu: normalizePrice(cena)
  };
  result.nazwaKoncowa = buildTyreName(result);
  return result;
}

module.exports = {
  cleanText,
  normalizePrice,
  normalizeQty,
  parseSize,
  parseLoadSpeed,
  parseTechnicalMarks,
  buildTyreName,
  normalizeBohnenkamp,
  normalizeJmk,
  normalizeGrasdorf,
  normalizeHandlopex,
  normalizeAgrowiec,
  normalizeNokian,
  normalizeTrelleborg,
  normalizeAgrorami,
  normalizeGri
};
