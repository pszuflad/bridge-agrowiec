BACKUP: Rozszerzenie dostepu do pliku eksportu CSV o IP Agrowiec
Data wdrozenia: 2026-07-24

Plik produkcyjny: /home/admin/domains/agritires.eu/public_html/panel/ex-port-files/.htaccess

Zawartosc:
- przed/.htaccess - wersja z dostepem tylko dla IP Selly (212.91.27.191)
- po/.htaccess     - wersja z dostepem dla IP Selly + IP Agrowiec (46.170.251.129)

Zmiana:
Dodano drugi dozwolony adres IP - 46.170.251.129 (siec Agrowiec, na potrzeby Marty)
do listy adresow majacych dostep do pliku:
https://panel.agritires.eu/ex-port-files/sellycsv-vDsrvHnz7jmyqlvtubo4g3JA.csv

Backup serwerowy wykonany przed edycja (pozostaje na serwerze):
.htaccess.bak_pre_agrowiec_ip_20260724_1624

Weryfikacja wykonana:
- Zawartosc pliku po wgraniu potwierdzona przez odczyt z serwera
- Test z zewnetrznego IP (nie Selly, nie Agrowiec) -> HTTP 403 (blokada nadal aktywna)
