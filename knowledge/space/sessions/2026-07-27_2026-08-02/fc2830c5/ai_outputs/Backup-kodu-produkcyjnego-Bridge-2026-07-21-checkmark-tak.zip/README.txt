Backup kodu produkcyjnego Bridge — 2026-07-21 (checkmark -> "Tak")
====================================================================

Zawartosc:
- index-KODIMP20260717124457.js.PRZED_ZMIANA.js  -> wersja pliku PRZED wprowadzeniem poprawki
- index-KODIMP20260717124457.js.PO_ZMIANIE_2026-07-21.js -> wersja PO wdrozeniu poprawki (aktualnie aktywna produkcyjnie)

Lokalizacja na serwerze (produkcyjna, publiczna):
/home/admin/domains/agritires.eu/public_html/panel/assets/index-KODIMP20260717124457.js

Zmiana:
Kolumny logiczne (boolean) na liscie produktow w panelu Bridge (3PMSF, M+S,
wzmocnienie, cut-resistant, heat-resistant, stubble-resistant, CFO, EAN valid)
wczesniej wyswietlaly znaczek "✓" dla wartosci prawda i "—" dla nieprawda/brak.
Zmieniono na tekst "Tak" dla prawda i puste pole (bez tekstu) dla nieprawda/brak.

Zmiana dotyczy jednej wspoldzielonej funkcji renderujacej komorki tabeli:
  PRZED: typeof n=="boolean"?n?"✓":"—"   (w zapisie zminifikowanym: "boolean"==typeof n?n?"✓":"—")
  PO:    typeof n=="boolean"?n?"Tak":""  (w zapisie zminifikowanym: "boolean"==typeof n?n?"Tak":"")

Backup produkcyjny na serwerze (sprzed zmiany):
/home/admin/domains/agritires.eu/public_html/panel/assets/index-KODIMP20260717124457.js.bak_pre_bool_tak_20260721_105953

Restart backendu: NIE byl wymagany (plik statyczny serwowany przez Apache,
zmiana widoczna natychmiast po wgraniu, Apache wysyla naglowki no-cache dla .js/.html/.css).

Zmian w bazie danych NIE wprowadzono — to wylacznie poprawka wyswietlania frontendu.
