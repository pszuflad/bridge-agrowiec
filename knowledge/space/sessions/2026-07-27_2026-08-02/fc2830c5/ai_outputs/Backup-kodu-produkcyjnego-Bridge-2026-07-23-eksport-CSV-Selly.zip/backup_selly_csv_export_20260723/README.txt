BACKUP: Eksport CSV dla Selly (pelny katalog, wszyscy dostawcy)
Data wdrozenia: 2026-07-23

Zawartosc:
- generate_selly_export.cjs
  Skrypt Node.js generujacy plik CSV z tabeli products (baza SQLite Bridge).
  Wdrozony na serwerze w: /home/admin/private_apps/bridge/generate_selly_export.cjs
  Generuje plik: /home/admin/domains/agritires.eu/public_html/panel/ex-port-files/sellycsv-vDsrvHnz7jmyqlvtubo4g3JA.csv
  Publiczny URL: https://panel.agritires.eu/ex-port-files/sellycsv-vDsrvHnz7jmyqlvtubo4g3JA.csv
  Format: 59 kolumn, separator ';', UTF-8 z BOM, CRLF - odwzorowuje strukture pliku
  wczesniej wyslanego mailem do integratora Selly. Zawiera WSZYSTKIE statusy produktow
  (nie tylko aktywne) i wszystkich dostawcow.

- htaccess_ex-port-files
  Plik .htaccess ograniczajacy dostep do katalogu ex-port-files wylacznie do adresu IP
  212.91.27.191 (staly adres IP integratora Selly, potwierdzony przez zespol).
  Wdrozony na serwerze w: /home/admin/domains/agritires.eu/public_html/panel/ex-port-files/.htaccess
  Zawiera skladnie kompatybilna z Apache 2.4 (Require ip) oraz fallback 2.2 (Order/Allow/Deny).

Automatyzacja:
- Zadanie CRON w panelu DirectAdmin (https://vpshd1242.cyber-folks.pl:2223/), domena agritires.eu
- Harmonogram: 0 6 * * * (codziennie o 6:00)
- Komenda: /home/admin/.nvm/versions/node/v20.20.2/bin/node /home/admin/private_apps/bridge/generate_selly_export.cjs >> /home/admin/private_apps/bridge/logs/selly_export_cron.log 2>&1

Weryfikacja wykonana:
- Recznie uruchomiony skrypt - poprawny plik (6941 wierszy, 59 kolumn, ~2.5 MB)
- curl z zewnatrz -> HTTP 403 (blokada IP dziala)
- Test w izolowanym srodowisku (env -i) symulujacy uruchomienie przez cron -> exit code 0
