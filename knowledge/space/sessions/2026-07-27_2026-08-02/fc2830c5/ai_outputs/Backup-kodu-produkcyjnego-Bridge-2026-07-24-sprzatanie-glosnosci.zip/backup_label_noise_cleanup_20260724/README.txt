BACKUP: Sprzatanie kolumny label_noise (glosnosc) w tabeli products
Data wdrozenia: 2026-07-24

Zawartosc:
- update_label_noise.sql - dokladny zapytanie SQL wykonane na produkcji

Backup bazy przed zmiana (pelna kopia, pozostaje na serwerze - 219 MB, zbyt duzy do przeslania):
/home/admin/private_apps/bridge/data.db.bak_pre_label_noise_cleanup_20260724_1727

Zmiana - normalizacja wartosci w kolumnie label_noise:
1. Liczby bez jednostki -> dodano "dB" (np. "73" -> "73dB") - 12 produktow
2. Male litery "db" -> zamieniono na "dB" (np. "73db" -> "73dB") - 3 produkty
3. Wartosci ze smieciowym tekstem -> wyciagnieto czysta wartosc
   (np. "73dB - )))" -> "73dB", "78dB - )))" -> "78dB", "72dB - )" -> "72dB") - 3 produkty
4. Wartosci bez zadnej liczby ("B", "dB") -> wyczyszczono do pustego pola - 4 produkty
5. Wartosc "24dB" (nietypowo niska, podejrzenie bledu danych) -> wyczyszczono do pustego pola - 1 produkt

Stan PRZED (unikalne wartosci i liczba produktow):
"" (puste): 5548 | 73dB: 296 | 71dB: 228 | 72dB: 191 | 74dB: 171 | 70dB: 164 | 69dB: 110
75dB: 102 | 76dB: 60 | 67dB: 22 | 68dB: 21 | 66dB: 3 | 70: 3 | B: 3 | 65dB: 2 | 73: 2
73db: 2 | 74: 2 | 24dB: 1 | 68: 1 | 69db: 1 | 71: 1 | 72: 1 | "72dB - )": 1
"73dB - )))": 1 | 75: 1 | 76: 1 | "78dB - )))": 1 | dB: 1

Stan PO (unikalne wartosci i liczba produktow):
"" (puste): 5553 | 65dB: 2 | 66dB: 3 | 67dB: 22 | 68dB: 22 | 69dB: 111 | 70dB: 167
71dB: 229 | 72dB: 193 | 73dB: 301 | 74dB: 173 | 75dB: 103 | 76dB: 61 | 78dB: 1

Weryfikacja wykonana:
- Calkowita liczba produktow bez zmian: 6941
- Brak jakichkolwiek wartosci niezgodnych z formatem NNdB lub pustym polem po aktualizacji
- Zadnych zmian w innych kolumnach ani czesciach panelu
