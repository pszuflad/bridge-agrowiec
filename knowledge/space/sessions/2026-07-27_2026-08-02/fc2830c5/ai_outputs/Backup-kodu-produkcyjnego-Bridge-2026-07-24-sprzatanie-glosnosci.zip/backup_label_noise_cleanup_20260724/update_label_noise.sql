-- Sprzatanie kolumny label_noise (glosnosc) w tabeli products
-- Wykonane: 2026-07-24
-- Backup bazy przed zmiana: data.db.bak_pre_label_noise_cleanup_20260724_1727

UPDATE products
SET label_noise = CASE
    WHEN label_noise = 'B' OR label_noise = 'dB' THEN ''
    WHEN label_noise = '24dB' THEN ''
    WHEN label_noise GLOB '[0-9]*' AND label_noise NOT GLOB '*[dD][bB]*' THEN label_noise || 'dB'
    WHEN label_noise GLOB '*db' THEN REPLACE(label_noise,'db','dB')
    WHEN label_noise LIKE '%dB - %' THEN SUBSTR(label_noise, 1, INSTR(label_noise,'dB')+1)
    ELSE label_noise
  END
WHERE label_noise IS NOT NULL AND label_noise != '';
